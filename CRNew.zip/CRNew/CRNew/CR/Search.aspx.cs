﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using FloraSoft.CR.DAL;
using System.Data;

namespace FloraSoft.CR
{
    public partial class Search : System.Web.UI.Page
    {
        ReportDB reportDB = new ReportDB();
      
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!(Request.Cookies["RoleID"].Value == "CRM" || Request.Cookies["RoleID"].Value == "CRC"))
            {
                Response.Redirect("~/AccessDenied.aspx");
            }
        }

        protected void btnShowHistory_Click(object sender, EventArgs e)
        {
            try
            {
                DateTime fromDate = Convert.ToDateTime(GetSystemReadableDate(txtFromDate.Text, true));
                DateTime toDate = Convert.ToDateTime(GetSystemReadableDate(txtToDate.Text, true));
                string Type = ddlType.SelectedValue.Trim();
                string Status = ddlStatus.SelectedValue.Trim();
                string DbtrAcctOthrId = txtAccountNo.Text.Trim();
                DataTable dtTransaction;

                if (ddlType.SelectedValue.Equals("All"))
                {
                    dtTransaction = reportDB.SearchALLChargeVatData(fromDate, toDate,  Status, DbtrAcctOthrId);
                }
                else if (ddlType.SelectedValue.Equals("Charge"))
                {
                    dtTransaction = reportDB.SearchChargeData(fromDate, toDate,  Status, DbtrAcctOthrId);
                }
                else
                {
                    dtTransaction = reportDB.SearchVATData(fromDate, toDate, Type, Status, DbtrAcctOthrId);
                }
              //  return dtTransaction;




                //DataTable dt = reportDB.Search(fromDate, toDate, Type, Status,AccountNo );
                gvHistory.DataSource = dtTransaction;
                gvHistory.DataBind();
            }
            catch { }
        }
        public DateTime GetSystemReadableDate(string strDate, bool isServer)
        {
            if (isServer == false)
                return Convert.ToDateTime(strDate);
            string[] arrayDate;
            string strNew = null;
            if (strDate.Contains("/"))
            {
                arrayDate = strDate.Split('/');
                strNew = arrayDate[1] + "/" + arrayDate[0] + "/" + arrayDate[2];
            }
            else
            {
                if (strDate.Contains("-"))
                {
                    arrayDate = strDate.Split('-');
                    strNew = arrayDate[1] + "-" + arrayDate[0] + "-" + arrayDate[2];
                }
            }

            return Convert.ToDateTime(strNew);
        }
    }
}