﻿using System;
using System.DirectoryServices.AccountManagement;

namespace FLoraSoft.CR.BLL
{
    public class IATPActiveDirectoryInfo
    {
        public bool IsAuthenticated(string srvr, string usr, string pwd)
        {
            bool isValid = false;
            try
            {
                using (PrincipalContext pc = new PrincipalContext(ContextType.Domain, srvr))
                {
                    // validate the credentials
                    isValid = pc.ValidateCredentials(usr, pwd);
                }
            }
            catch (Exception ex)
            {
                throw ex;
                //label1.Text = "Error: " + cex.Message;
            }

            return isValid;
        }
    }
}