﻿using System.Data;
using System.Text;

namespace FLoraSoft.CR.BLL
{
    public class FlatFileTransactionsent
    {
        public string GetTransaction_for_FlatFileGenerate(DataTable dt)
        {
            //string delim = ConfigurationManager.AppSettings["Delim"];

            string result = string.Empty;

            //double totalDebitAmount = 0;

            foreach (DataRow row in dt.Rows)
            {
                string CurrencyCode = "BDT";
                string AccountNo = row["AccountNo"].ToString();
                string Amount = row["Amount"].ToString();
                string DorC = row["DorC"].ToString();
                string TranType = row["TranType"].ToString();
                string valueDate = row["valueDate"].ToString();
                string Narration1 = row["Narration1"].ToString();
                string TraceNumber = row["TraceNumber"].ToString();

                //totalDebitAmount += EFTN.Utility.ParseData.StringToDouble(Amount.Trim());

                //if (AccountNo.Trim().Length == 13)
                //{
                StringBuilder line = new StringBuilder();
                line.Append(CurrencyCode);
                line.Append(AccountNo);
                line.Append(Amount);
                line.Append(DorC);
                line.Append(TranType);
                line.Append(valueDate);
                line.Append(TraceNumber);
                line.AppendLine(Narration1);

                //line += (CurrencyCode);
                //line += (AccountNo);
                //line += (Amount);
                //line += (DorC);
                //line += (TranType);
                //line += (valueDate);
                //line += (Narration1);


                //if (result.Equals(string.Empty))
                //{
                //    result += line;
                //}

                //else
                //{
                //    result += "\n" + line;
                //}
                result += line.ToString();
            }
            return result;
        }

    }
}