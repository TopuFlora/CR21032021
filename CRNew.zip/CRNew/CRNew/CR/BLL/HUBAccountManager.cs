﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Threading;

namespace FLoraSoft.CR.BLL
{
    public class HUBAccountManager
    {
        public void SynchronizeHUBAccountByTransactionID(Guid TransactionID, string UserID)
        {
            FLoraSoft.CR.DAL.HUBAccountDB hubAccountDB = new FLoraSoft.CR.DAL.HUBAccountDB();
            DataTable dtDistincAccount = hubAccountDB.GetDistinctAccNoByTransactionID(TransactionID);

            try
            {
                InsertHUBAccount(dtDistincAccount, UserID);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //private static void InsertHUBAccount(DataTable dtDistinchAccount)
        //{
        //    HUBAccountDB hubAccountDB = new HUBAccountDB();

        //    try
        //    {
        //        FloraServiceForHSBCMQ.MQWebService mqservice = new FloraServiceForHSBCMQ.MQWebService();
        //        for (int i = 0; i < dtDistinchAccount.Rows.Count; i++)
        //        {
        //            string AccountNo = dtDistinchAccount.Rows[i]["AccountNo"].ToString();

        //            //string mqRequest = mqservice.GetRequestMQ(AccountNo, UserID);
        //            //string mqResponse = mqservice.GetResponse(AccountNo, "43857385", "N");//temporarily using this line 
        //            //otherwise uncomment upper line
        //            //and comment this line
        //            string mqResponse = mqservice.GetHUBData(AccountNo, "43857385", "N");//temporarily using this line 

        //            Dictionary<string, string> dictionary = new Dictionary<string, string>();
        //            string[] items = mqResponse.TrimEnd('~').Split('~');
        //            foreach (string item in items)
        //            {
        //                string[] keyValue = item.Split('=');
        //                dictionary.Add(keyValue[0], keyValue[1]);
        //            }

        //            //dictionary[
        //            string mq_AccountName = string.Empty;
        //            string mq_AccType = string.Empty;
        //            string mq_AccountStatus = string.Empty;
        //            string mq_AccountRestrisction = string.Empty;
        //            string mq_SpecialInstruction1 = string.Empty;
        //            string mq_SpecialInstruction2 = string.Empty;
        //            string mq_GHOClassification = string.Empty;
        //            string mq_Others = string.Empty;

        //            if (!mqResponse.Contains("invalid account"))
        //            {
        //                try
        //                {
        //                    mq_AccountName = dictionary["AccountName"].ToString();
        //                    mq_AccountStatus = dictionary["AccountStatus"].ToString();
        //                    mq_AccountRestrisction = dictionary["AccountRestriction"].ToString();
        //                    mq_SpecialInstruction1 = dictionary["SpInstruc1"].ToString();
        //                    mq_GHOClassification = dictionary["GHO"].ToString();
        //                }
        //                catch
        //                {
        //                }
        //            }

        //            hubAccountDB.InsertHUBMapper(mq_AccountName, mq_GHOClassification, mq_AccType, mq_AccountStatus, mq_AccountRestrisction, mq_SpecialInstruction1, AccountNo, mq_Others);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        private void InsertHUBAccount(DataTable dtDistinctAccount, string UserID)
        {
            try
            {
                for (int i = 0; i < dtDistinctAccount.Rows.Count; i++)
                {
                    if (i % 30 == 0)
                    {
                        Thread.Sleep(5000);
                    }
                    MQThreadExecution mq = new MQThreadExecution();
                    //Thread tid1 = new Thread(new ThreadStart(mq.InsertHUBAccountChild));
                    //mq.UserID = UserID;
                    //mq.AccountNo = dtDistinctAccount.Rows[i]["AccountNo"].ToString();
                    //tid1.Start();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //private void InsertHUBAccountChild(string AccountNo)
        //{
        //    HUBAccountDB hubAccountDB = new HUBAccountDB();

        //    try
        //    {
        //        FloraServiceForHSBCMQ.MQWebService mqservice = new FloraServiceForHSBCMQ.MQWebService();

        //        //string mqRequest = mqservice.GetRequestMQ(AccountNo, UserID);
        //        string mqResponse = mqservice.GetResponse(AccountNo, "43857385", "N");//temporarily using this line 
        //        //otherwise uncomment upper line
        //        //and comment this line

        //        string mq_AccountName = string.Empty;
        //        string mq_AccType = string.Empty;
        //        string mq_AccountStatus = string.Empty;
        //        string mq_AccountRestrisction = string.Empty;
        //        string mq_SpecialInstruction1 = string.Empty;
        //        string mq_SpecialInstruction2 = string.Empty;
        //        string mq_GHOClassification = string.Empty;
        //        string mq_Others = string.Empty;

        //        if (!mqResponse.Contains("invalid account"))
        //        {
        //            try
        //            {
        //                mq_AccountName = mqResponse.Substring(640, 28);
        //                mq_AccountStatus = mqResponse.Substring(1538, 8);
        //                mq_AccountRestrisction = mqResponse.Substring(1598, 50);
        //                mq_SpecialInstruction1 = mqResponse.Substring(1598, 50);
        //                mq_GHOClassification = mqResponse.Substring(1598, 50);
        //            }
        //            catch
        //            {
        //            }
        //        }

        //        hubAccountDB.InsertHUBMapper(mq_AccountName, mq_GHOClassification, mq_AccType, mq_AccountStatus, mq_AccountRestrisction, mq_SpecialInstruction1, AccountNo, mq_Others);

        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}
    }
    public  class MQThreadExecution
    {
        public string AccountNo = "";
        public string UserID = "";

        //public  void InsertHUBAccountChild()
        //{
        //    FLoraSoft.CR.DAL.HUBAccountDB hubAccountDB = new FLoraSoft.CR.DAL.HUBAccountDB();

        //    try
        //    {
        //        FloraServiceForHSBCMQ.MQWebService mqservice = new FloraServiceForHSBCMQ.MQWebService();

        //        //string mqRequest = mqservice.GetRequestMQ(AccountNo, UserID);
        //        //string mqResponse = mqservice.GetHUBData(AccountNo, "43857385", "N");//temporarily using this line 
        //        string mqResponse = mqservice.GetHUBData(AccountNo, UserID);//temporarily using this line 
        //        //otherwise uncomment upper line
        //        //and comment this line
              
        //        Dictionary<string, string> names = new Dictionary<string, string>();
        //        string[] arr = mqResponse.Split('~');
        //        foreach (string ar1 in arr)
        //        {
        //            string[] itemArr = ar1.Split('=');
        //            if (itemArr.Length > 1)
        //            {
        //                names.Add(itemArr[0], itemArr[1]);
        //            }
        //        }

        //        string mq_AccountName = string.Empty;
        //        string mq_AccType = string.Empty;
        //        string mq_AccountStatus = string.Empty;
        //        string mq_AccountRestrisction = string.Empty;
        //        string mq_SpecialInstruction1 = string.Empty;
        //        string mq_GHOClassification = string.Empty;
        //        string mq_Others = string.Empty;

        //        if (!mqResponse.Contains("invalid account"))
        //        {
        //            if (arr.Length > 1)
        //            {
        //                if (mqResponse.Contains("AccountName="))
        //                {
        //                    mq_AccountName = names["AccountName"];
        //                }
        //                if (mqResponse.Contains("AccountStatus="))
        //                {
        //                    mq_AccountStatus = names["AccountStatus"];
        //                }
        //                if (mqResponse.Contains("AccountRestriction="))
        //                {
        //                    mq_AccountRestrisction = names["AccountRestriction"];
        //                }
        //                if (mqResponse.Contains("SPInstruc="))
        //                {
        //                    mq_SpecialInstruction1 = names["SPInstruc"];
        //                }
        //                if (mqResponse.Contains("GHO="))
        //                {
        //                    mq_GHOClassification = names["GHO"];
        //                }
        //            }
        //        }

        //        hubAccountDB.InsertHUBMapper(mq_AccountName, mq_GHOClassification, mq_AccType, mq_AccountStatus, mq_AccountRestrisction, mq_SpecialInstruction1, AccountNo, mq_Others);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}
    }
}