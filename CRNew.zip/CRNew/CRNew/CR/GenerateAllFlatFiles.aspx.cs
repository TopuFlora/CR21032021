﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using System.Configuration;
using ICSharpCode.SharpZipLib.Zip;
using iTextSharp.text.pdf;
using iTextSharp.text;
using FLoraSoft.CR.DAL;
using ClosedXML.Excel;
using Florasoft.CR.Utility;
using FLoraSoft.CR.BLL;

namespace FloraSoft.CR
{
    public partial class GenerateAllFlatFiles : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ddlistDay.SelectedValue = System.DateTime.Now.Day.ToString().PadLeft(2, '0');
                ddlistMonth.SelectedValue = System.DateTime.Now.Month.ToString();
                ddlistYear.SelectedValue = System.DateTime.Now.Year.ToString();

                string SelectEntryDate = ddlistYear.SelectedValue.PadLeft(4, '0')
         + ddlistMonth.SelectedValue.PadLeft(2, '0')
         + ddlistDay.SelectedValue.PadLeft(2, '0');

                //BindFlatFileBatches();
            }
        }

        //protected void Page_PreRender(object sender, EventArgs e)
        //{
        //    for (int i = 0; i < this.gridViewTransaction.Rows.Count; i++)
        //    {
        //        ((CheckBox)this.gridViewTransaction.Rows[i].FindControl("chkID")).Checked = chkBxSelect.Checked;
        //    }
        //}
        private void BindFlatFileTransaction()
        {
            string SelectEntryDate = ddlistYear.SelectedValue.PadLeft(4, '0')
                                 + ddlistMonth.SelectedValue.PadLeft(2, '0')
                                 + ddlistDay.SelectedValue.PadLeft(2, '0');


            FLoraSoft.CR.DAL.FlatFileDB flatFileDB = new FLoraSoft.CR.DAL.FlatFileDB();

            gridViewTransaction.DataSource = flatFileDB.GetTransaction_for_FlatFile();
            gridViewTransaction.DataBind();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            BindFlatFileTransaction();
        }

        private void genZipFile(string filename, string pwd, Stream fs)
        {
            //Response Header
            string zipFileName;
            zipFileName = filename + ".zip";

            Response.Clear();
            //Response.ClearHeaders();
            //Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //Response.StatusCode = 200;



            try
            {
                using (ZipOutputStream s = new ZipOutputStream(Response.OutputStream))
                {
                    s.Password = pwd;
                    s.SetLevel(4); // 0 - store only to 9 - means best compression

                    byte[] buffer = new byte[4096];

                    ZipEntry entry = new ZipEntry(ZipEntry.CleanName(filename));
                    entry.DateTime = DateTime.Now;
                    s.PutNextEntry(entry);


                    int sourceBytes;
                    do
                    {
                        sourceBytes = fs.Read(buffer, 0, buffer.Length);
                        s.Write(buffer, 0, sourceBytes);
                    } while (sourceBytes > 0);

                    s.Finish();

                    s.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
                //MessageBox.Show("Exception during processing " + ex.Message);
            }
            string contentValue = string.Format("attachment; filename=" + zipFileName);
            Response.ContentType = "application/x-zip-compressed";
            Response.AddHeader("Content-Disposition", contentValue);
            Response.End();
        }

        protected void gridViewTransaction_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow &&
               (e.Row.RowState == DataControlRowState.Normal ||
                e.Row.RowState == DataControlRowState.Alternate))
            {
                CheckBox chkBxSelect = (CheckBox)e.Row.Cells[1].FindControl("chkBxSelect");
                CheckBox chkBxHeader = (CheckBox)this.gridViewTransaction.HeaderRow.FindControl("chkBxHeader");
                chkBxSelect.Attributes["onclick"] = string.Format
                                                       (
                                                          "javascript:ChildClick(this,'{0}');",
                                                          chkBxHeader.ClientID
                                                       );
            }

        }

        protected void btnGenerate_Click(object sender, EventArgs e)
        {
            //string SelectEntryDate = ddlistYear.SelectedValue.PadLeft(4, '0')
            //                     + ddlistMonth.SelectedValue.PadLeft(2, '0')
            //                     + ddlistDay.SelectedValue.PadLeft(2, '0');
            FlatFileDB flatFileDB = new FlatFileDB();
            //flatFileDB.ClearFlatFileTable();

            foreach (GridViewRow item in gridViewTransaction.Rows)
            {
                CheckBox myCheckBox = (CheckBox)item.FindControl("chkBxSelect");

                if (myCheckBox.Checked)
                {
                    string strTransactionID = gridViewTransaction.DataKeys[item.RowIndex].Value.ToString();
                    Guid TransactionID = Guid.Parse(strTransactionID);
                    flatFileDB.InsertTransactionIDForFlatFile(TransactionID);
                }
            }



            DataTable dtFlatFile = flatFileDB.GetTransaction_for_FlatFileGenerate();

            string fileName = string.Empty;

            fileName = "BDGD" + HSBCNamingConvension.GetMonth(System.DateTime.Now.Month) + System.DateTime.Now.Day.ToString().PadLeft(2, '0') + System.DateTime.Now.Second.ToString().PadLeft(2, '0');
            FlatFileTransactionsent fc = new FlatFileTransactionsent();

            string flatfileResult = fc.GetTransaction_for_FlatFileGenerate(dtFlatFile);
            StreamFromStringGenerator generator = new StreamFromStringGenerator();

            Stream stream = generator.GenerateStreamFromString(flatfileResult);

            string myActiveDirSvr = ConfigurationManager.AppSettings["HSBCActiveDirectoryConnection"];
            string pkZipPassword = ConfigurationManager.AppSettings["PKZipPassword"];

            genZipFile(fileName, pkZipPassword, stream);

            //Response.Redirect("IATPBatchesForFlatFiles.aspx");
            //BindFlatFileBatches();
        }

          protected void btnGeneratePDF_Click(object sender, EventArgs e)
        {
            FlatFileDB flatFileDB = new FlatFileDB();
            flatFileDB.ClearFlatFileTable();

            foreach (GridViewRow item in gridViewTransaction.Rows)
            {
                CheckBox myCheckBox = (CheckBox)item.FindControl("chkBxSelect");

                if (myCheckBox.Checked)
                {
                    string strTransactionID = gridViewTransaction.DataKeys[item.RowIndex].Value.ToString();
                    Guid TransactionID = Guid.Parse(strTransactionID);
                    flatFileDB.InsertTransactionIDForFlatFile(TransactionID);
                }
            }

            DataTable dtFlatFile = flatFileDB.GetTransaction_for_FlatFile();

            string FileName = "Transaction-Report" + System.DateTime.Now.ToString("yyyyMMddHHmmss") + ".pdf";

            PrintPDF(FileName, dtFlatFile, string.Empty);
        }

        private void PrintPDF(string FileName, DataTable dt, string ReportType)
        {
            if (dt.Rows.Count == 0)
            {
                return;
            }

            Response.ClearContent();
            Response.ContentType = "application/pdf";
            Response.AddHeader("Content-Disposition", "attachment; filename=" + FileName);

            Document document = new Document(PageSize.A4.Rotate(), 10, 10, 8, 8);
            PdfWriter writer = PdfWriter.GetInstance(document, Response.OutputStream);

            Font fnt = new Font(Font.HELVETICA, 8);
            Font fntblue = new Font(Font.HELVETICA, 8);
            fntblue.Color = new Color(0, 0, 255);
            Font fntbld = new Font(Font.HELVETICA, 8);
            fntbld.SetStyle(Font.BOLD);
            Font headerFont = new Font(Font.HELVETICA, 15);

            string spacer = "            -              ";

            string str = spacer;
            str = str + "HSBC All Rights Reserved" + spacer;
            str = str + "Confidential: internal use only" + spacer;
            str = str + "Powered By Flora Limited";

            HeaderFooter footer = new HeaderFooter(new Phrase(str, fnt), false);
            footer.Alignment = Element.ALIGN_CENTER;

            document.Footer = footer;
            document.Open();

            string LogoImage = Server.MapPath("img") + "\\logo.png";

            iTextSharp.text.Image jpeg = iTextSharp.text.Image.GetInstance(LogoImage);
            jpeg.Alignment = Element.ALIGN_RIGHT;


            PdfPCell logo = new PdfPCell();
            logo.BorderWidth = 0;
            logo.Colspan = 2;
            logo.AddElement(jpeg);

            ////////////////////////////////
            iTextSharp.text.pdf.PdfPTable headertable = new iTextSharp.text.pdf.PdfPTable(3);
            headertable.DefaultCell.Border = Rectangle.NO_BORDER;
            headertable.DefaultCell.VerticalAlignment = Cell.ALIGN_BOTTOM;
            headertable.DefaultCell.Padding = 0;
            headertable.WidthPercentage = 99;
            headertable.DefaultCell.Border = 0;
            float[] widthsAtHeader = { 50, 30, 20 };
            headertable.SetWidths(widthsAtHeader);

            string settlementDate = ddlistDay.SelectedValue + "/" + ddlistMonth.SelectedValue.PadLeft(2, '0') + "/" + ddlistYear.SelectedValue;
            headertable.AddCell(new Phrase(ReportType + " Transaction Report: " + settlementDate, headerFont));


            headertable.AddCell(new Phrase("Report Generated Time: " + System.DateTime.Now.ToString(), headerFont));
            //headertable.AddCell(new Phrase(""));
            headertable.AddCell(logo); ;
            document.Add(headertable);

            document.Add(new iTextSharp.text.Paragraph(" "));
            iTextSharp.text.pdf.PdfPTable datatable = new iTextSharp.text.pdf.PdfPTable(6);
            datatable.DefaultCell.Padding = 4;
            datatable.DefaultCell.BorderColor = new iTextSharp.text.Color(200, 200, 200);
            float[] headerwidths = { 16, 16, 16, 20, 16, 16 };
            datatable.SetWidths(headerwidths);
            datatable.WidthPercentage = 99;

            iTextSharp.text.pdf.BaseFont bf = iTextSharp.text.pdf.BaseFont.CreateFont(iTextSharp.text.pdf.BaseFont.HELVETICA, iTextSharp.text.pdf.BaseFont.WINANSI, iTextSharp.text.pdf.BaseFont.NOT_EMBEDDED);

            datatable.DefaultCell.BorderWidth = 0.5f;
            datatable.DefaultCell.HorizontalAlignment = iTextSharp.text.Element.ALIGN_RIGHT;
            datatable.DefaultCell.BackgroundColor = new iTextSharp.text.Color(200, 200, 200);
            //------------------------------------------

            //PdfPCell c0 = new PdfPCell(new iTextSharp.text.Phrase("Register Date", fnt));
            //c0.BorderWidth = 0.5f;
            //c0.HorizontalAlignment = Cell.ALIGN_LEFT;
            //c0.BackgroundColor = new iTextSharp.text.Color(200, 200, 200);
            //c0.BorderColor = new iTextSharp.text.Color(200, 200, 200);
            //c0.Padding = 4;

            //datatable.AddCell(c0);


            //datatable.AddCell(new iTextSharp.text.Phrase("BatchNumber", fnt));
            datatable.AddCell(new iTextSharp.text.Phrase("AccountNo", fnt));
            datatable.AddCell(new iTextSharp.text.Phrase("Amount", fnt));
            datatable.AddCell(new iTextSharp.text.Phrase("DocNo", fnt));
            datatable.AddCell(new iTextSharp.text.Phrase("AccountName", fnt));
            datatable.AddCell(new iTextSharp.text.Phrase("TraceNumber", fnt));
            datatable.AddCell(new iTextSharp.text.Phrase("Narration1", fnt));
            //datatable.AddCell(new iTextSharp.text.Phrase("", fnt));

            datatable.HeaderRows = 1;
            datatable.DefaultCell.BackgroundColor = new iTextSharp.text.Color(255, 255, 255);
            datatable.DefaultCell.BorderWidth = 0.25f;


            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //PdfPCell c1 = new PdfPCell(new iTextSharp.text.Phrase(dt.Rows[i]["BatchNumber"].ToString(), fnt));
                //c1.BorderWidth = 0.5f;
                //c1.HorizontalAlignment = Cell.ALIGN_LEFT;
                //c1.BorderColor = new iTextSharp.text.Color(200, 200, 200);
                //c1.Padding = 1;
                //datatable.AddCell(c1);

                PdfPCell c2 = new PdfPCell(new iTextSharp.text.Phrase((string)dt.Rows[i]["AccountNo"], fnt));
                c2.BorderWidth = 0.5f;
                c2.HorizontalAlignment = Cell.ALIGN_LEFT;
                c2.BorderColor = new iTextSharp.text.Color(200, 200, 200);
                c2.Padding = 4;
                datatable.AddCell(c2);

                datatable.AddCell(new iTextSharp.text.Phrase(ParseData.StringToDouble(dt.Rows[i]["RealAmount"].ToString()).ToString("N", System.Globalization.CultureInfo.InvariantCulture), fnt));

                PdfPCell c3 = new PdfPCell(new iTextSharp.text.Phrase((string)dt.Rows[i]["DocNo"], fnt));
                c3.BorderWidth = 0.5f;
                c3.HorizontalAlignment = Cell.ALIGN_LEFT;
                c3.BorderColor = new iTextSharp.text.Color(200, 200, 200);
                c3.Padding = 4;
                datatable.AddCell(c3);


                PdfPCell c4 = new PdfPCell(new iTextSharp.text.Phrase((string)dt.Rows[i]["AccountName"], fnt));
                c4.BorderWidth = 0.5f;
                c4.HorizontalAlignment = Cell.ALIGN_LEFT;
                c4.BorderColor = new iTextSharp.text.Color(200, 200, 200);
                c4.Padding = 4;
                datatable.AddCell(c4);


                PdfPCell c5 = new PdfPCell(new iTextSharp.text.Phrase((string)dt.Rows[i]["TraceNumber"], fnt));
                c5.BorderWidth = 0.5f;
                c5.HorizontalAlignment = Cell.ALIGN_LEFT;
                c5.BorderColor = new iTextSharp.text.Color(200, 200, 200);
                c5.Padding = 4;
                datatable.AddCell(c5);



                PdfPCell c6 = new PdfPCell(new iTextSharp.text.Phrase((string)dt.Rows[i]["Narration1"], fnt));
                c6.BorderWidth = 0.5f;
                c6.HorizontalAlignment = Cell.ALIGN_LEFT;
                c6.BorderColor = new iTextSharp.text.Color(200, 200, 200);
                c6.Padding = 4;
                datatable.AddCell(c6);

                //PdfPCell c7 = new PdfPCell(new iTextSharp.text.Phrase("", fnt));
                //c7.BorderWidth = 0.5f;
                //c7.HorizontalAlignment = Cell.ALIGN_LEFT;
                //c7.BorderColor = new iTextSharp.text.Color(200, 200, 200);
                //c7.Padding = 4;
                //datatable.AddCell(c7);
            }

            //-------------TOTAL IN FOOTER --------------------
            datatable.AddCell(new iTextSharp.text.Phrase("TOTAL", fntbld));
            datatable.AddCell(new iTextSharp.text.Phrase(ParseData.StringToDouble(dt.Compute("SUM(RealAmount)", "").ToString()).ToString("N", System.Globalization.CultureInfo.InvariantCulture), fntbld));
            datatable.AddCell(new iTextSharp.text.Phrase(dt.Compute("COUNT(AccountNo)", "").ToString(), fntbld));
            datatable.AddCell(new iTextSharp.text.Phrase("", fntbld));
            datatable.AddCell(new iTextSharp.text.Phrase("", fntbld));
            datatable.AddCell(new iTextSharp.text.Phrase("", fntbld));
            //-------------END TOTAL -------------------------
            document.Add(datatable);

            document.Close();
            Response.End();

        }

    }
       
}