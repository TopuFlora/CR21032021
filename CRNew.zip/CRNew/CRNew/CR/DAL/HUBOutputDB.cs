﻿using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using FloraSoft.CR.DAL;

namespace FLoraSoft.CR.DAL
{
    public class HUBOutputDB
    {
        public void UpdateTransactionSent_FlatFileACK_FromHUB(string TraceNumber,
                                                         string AccountNumber,
                                                            decimal Amount,
                                                            string SPI,
                                                            string TrnStatus,
                                                            string RejectReason)
        {
            SqlConnection myConnection = new SqlConnection(FLoraSoft.CR.DAL.AppVariables.ConStrVVDD);
            SqlDataAdapter myAdapter = new SqlDataAdapter("IATP_Update_TransactionSent_FlatFileACK", myConnection);
            myAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;
            myAdapter.SelectCommand.CommandTimeout = 600;

            SqlParameter parameterTraceNumber = new SqlParameter("@TraceNumber", SqlDbType.NVarChar, 15);
            parameterTraceNumber.Value = TraceNumber;
            myAdapter.SelectCommand.Parameters.Add(parameterTraceNumber);

            SqlParameter parameterAccountNumber = new SqlParameter("@AccountNumber", SqlDbType.NVarChar, 15);
            parameterAccountNumber.Value = AccountNumber;
            myAdapter.SelectCommand.Parameters.Add(parameterAccountNumber);

            SqlParameter parameterAmount = new SqlParameter("@Amount", SqlDbType.Money);
            parameterAmount.Value = Amount;
            myAdapter.SelectCommand.Parameters.Add(parameterAmount);

            SqlParameter parameterSPI = new SqlParameter("@SPI", SqlDbType.NVarChar, 30);
            parameterSPI.Value = SPI;
            myAdapter.SelectCommand.Parameters.Add(parameterSPI);

            SqlParameter parameterTrnStatus = new SqlParameter("@TrnStatus", SqlDbType.NVarChar, 10);
            parameterTrnStatus.Value = TrnStatus;
            myAdapter.SelectCommand.Parameters.Add(parameterTrnStatus);

            SqlParameter parameterRejectReason = new SqlParameter("@RejectReason", SqlDbType.NVarChar, 30);
            parameterRejectReason.Value = RejectReason;
            myAdapter.SelectCommand.Parameters.Add(parameterRejectReason);

            DataTable myDT = new DataTable();
            myConnection.Open();
            myAdapter.Fill(myDT);
            myConnection.Close();
        }
    }
}