using System;
using System.Data;
using System.Configuration;
using System.Data.OleDb;


namespace FloraSoft.CR.DAL
{
    public class ExcelDB
    {
        public DataTable GetData(string fileName)
        {
            string fileExtension = System.IO.Path.GetExtension(fileName);
            string connectionString = string.Empty;
            if (fileExtension.ToLower().Equals(".xls"))
            {
                connectionString = ConfigurationManager.AppSettings["ExcelConnectionString"];
            }
            else
            {
                connectionString = ConfigurationManager.AppSettings["ExcelConnectionStringForXLSX"];
            }
            OleDbConnection connection = new OleDbConnection(connectionString + fileName + "'");

            OleDbCommand command = new OleDbCommand();
            command.CommandText = "SELECT * FROM [Sheet1$]";
            command.Connection = connection;

            DataTable dt = new DataTable();
            OleDbDataAdapter adapter = new OleDbDataAdapter();
            adapter.SelectCommand = command;

            try
            {
                connection.Open();
                adapter.Fill(dt);
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public DataTable GetDataTableFromDynamicSheetName(string fileName, int workSheetNumber)
        {
            string fileExtension = System.IO.Path.GetExtension(fileName);
            string connectionString = string.Empty;
            string sheetName = GetExcelWorkSheet(fileName, workSheetNumber, fileExtension);
            if (fileExtension.ToLower().Equals(".xls"))
            {
                connectionString = ConfigurationManager.AppSettings["ExcelConnectionString"];
            }
            else
            {
                connectionString = ConfigurationManager.AppSettings["ExcelConnectionStringForXLSX"];
            }
            OleDbConnection connection = new OleDbConnection(connectionString + fileName + "'");

            OleDbCommand command = new OleDbCommand();
            command.CommandText = "SELECT * FROM " + sheetName;//String.Format("select * from [{0}${1}]", "Sheet1", "A" + RowNumber + ":ZZ");
            command.Connection = connection;

            DataTable dt = new DataTable();
            OleDbDataAdapter adapter = new OleDbDataAdapter();
            adapter.SelectCommand = command;

            try
            {
                connection.Open();

                adapter.Fill(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
                System.IO.File.Delete(fileName);
            }

            return dt;
        }

        private string GetExcelWorkSheet(string pathName, int workSheetNumber, string fileExtension)
        {
            try
            {
                OleDbConnection ExcelConnection;
                if (fileExtension.ToLower().Equals(".xls"))
                {
                    ExcelConnection = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + pathName + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1\";");
                }
                else
                {
                    ExcelConnection = new OleDbConnection(@"provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + pathName + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\";");
                }

                //string sDestConstr = ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString;
                //string Uid = HttpContext.Current.Session["UserName"].ToString();
                //string Pwd = HttpContext.Current.Session["Password"].ToString();
                //string DB = HttpContext.Current.Session["Database"].ToString();
                //string DS = HttpContext.Current.Session["Server"].ToString();

                //string ConStr = "Data Source='" + DS + "';Initial Catalog='" + DB + "';User ID='" + Uid + "';Password='" + Pwd + "'";

                OleDbCommand ExcelCommand = new OleDbCommand();
                ExcelCommand.Connection = ExcelConnection;
                OleDbDataAdapter ExcelAdapter = new OleDbDataAdapter(ExcelCommand);
                ExcelConnection.Open();

                #region Get Excel Sheets in a DataTable

                DataTable ExcelSheets = ExcelConnection.GetOleDbSchemaTable(System.Data.OleDb.OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                string SpreadSheetName = "[" + ExcelSheets.Rows[workSheetNumber]["TABLE_NAME"].ToString() + "]";
                DataSet ExcelDataSet = new DataSet();
                ExcelCommand.CommandText = string.Format(@"SELECT * FROM " + SpreadSheetName);
                ExcelAdapter.Fill(ExcelDataSet);

                ExcelConnection.Close();

                #endregion

                return SpreadSheetName;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
