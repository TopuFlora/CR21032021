﻿using System;
using System.Data.SqlClient;
using System.Data;

namespace FLoraSoft.CR.DAL
{
    public class FlatFileDB
    {
        public SqlDataReader GetTransaction_For_Generate_FlatFile(string SelectEntryDate)
        {// Must enter your connection string
            SqlConnection myConnection = new SqlConnection(FLoraSoft.CR.DAL.AppVariables.ConStrVVDD);
            // Must write your procedure name 
            SqlCommand myCommand = new SqlCommand("CR_FlatFileData", myConnection);
            myCommand.CommandType = CommandType.StoredProcedure;

            SqlParameter parameterSelectEntryDate = new SqlParameter("@SelectEntryDate", SqlDbType.VarChar);
            parameterSelectEntryDate.Value = SelectEntryDate;
            myCommand.Parameters.Add(parameterSelectEntryDate);


            myConnection.Open();
            SqlDataReader dr = myCommand.ExecuteReader(CommandBehavior.CloseConnection);
            return dr;
        }

        public SqlDataReader GetTransaction_for_FlatFileDebit(string SelectEntryDate)
        {// Must enter your connection string
            SqlConnection myConnection = new SqlConnection(FLoraSoft.CR.DAL.AppVariables.ConStrVVDD);
            // Must write your procedure name 
            SqlCommand myCommand = new SqlCommand("CR_FlatFileData", myConnection);
            myCommand.CommandType = CommandType.StoredProcedure;

            SqlParameter parameterSelectEntryDate = new SqlParameter("@SelectEntryDate", SqlDbType.VarChar);
            parameterSelectEntryDate.Value = @SelectEntryDate;
            myCommand.Parameters.Add(parameterSelectEntryDate);


            myConnection.Open();
            SqlDataReader dr = myCommand.ExecuteReader(CommandBehavior.CloseConnection);
            return dr;
        }

        public DataTable GetTransaction_for_FlatFile()
        {
            // Must enter your connection string
            SqlConnection myConnection = new SqlConnection(FLoraSoft.CR.DAL.AppVariables.ConStrVVDD);
            // Must write your procedure name 
            string spName = "CR_FlatFileDatacheck";
            SqlDataAdapter myAdapter = new SqlDataAdapter(spName, myConnection);
            myAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;
            myAdapter.SelectCommand.CommandTimeout = 600;

            DataTable myDT = new DataTable();
            myConnection.Open();
            myAdapter.Fill(myDT);
            myConnection.Close();
            return myDT;
        }

        public DataTable GetTransaction_for_FlatFileGenerate()
        {
            // Must enter your connection string
            SqlConnection myConnection = new SqlConnection(FLoraSoft.CR.DAL.AppVariables.ConStrVVDD);
            // Must write your procedure name 
            string spName = "CR_FlatFileDatacheckGenerate";
            SqlDataAdapter myAdapter = new SqlDataAdapter(spName, myConnection);
            myAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;
            myAdapter.SelectCommand.CommandTimeout = 600;

            DataTable myDT = new DataTable();
            myConnection.Open();
            myAdapter.Fill(myDT);
            myConnection.Close();
            return myDT;
        }

        public DataTable GetTransactionSentDebit_IATP_FlatFile()
        {
            // Must enter your connection string
            SqlConnection myConnection = new SqlConnection(FLoraSoft.CR.DAL.AppVariables.ConStrVVDD);
            // Must write your procedure name 
            string spName = "CR_FlatFileData";
            SqlDataAdapter myAdapter = new SqlDataAdapter(spName, myConnection);
            myAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;
            myAdapter.SelectCommand.CommandTimeout = 600;

            DataTable myDT = new DataTable();
            myConnection.Open();
            myAdapter.Fill(myDT);
            myConnection.Close();
            return myDT;
        }

        public void InsertTransactionIDForFlatFile(Guid TransactionID)
        {
            // Must enter your connection string
            SqlConnection myConnection = new SqlConnection(FLoraSoft.CR.DAL.AppVariables.ConStrVVDD);
            // Must write your procedure name 
            string spName = "CR_FlatFileDataIndivisuals";
            SqlDataAdapter myAdapter = new SqlDataAdapter(spName, myConnection);
            myAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;
            myAdapter.SelectCommand.CommandTimeout = 600;

            SqlParameter parameterTransactionID = new SqlParameter("@TransactionID", SqlDbType.UniqueIdentifier);
            parameterTransactionID.Value = TransactionID;
            myAdapter.SelectCommand.Parameters.Add(parameterTransactionID);

            myConnection.Open();
            myAdapter.SelectCommand.ExecuteNonQuery();
            myConnection.Close();
            myConnection.Dispose();
        }

        public SqlDataReader GetRejectedTransaction_ForFlatFile(string EDREntryDate)
        {// Must enter your connection string
            SqlConnection myConnection = new SqlConnection(FLoraSoft.CR.DAL.AppVariables.ConStrVVDD);
            // Must write your procedure name 
            SqlCommand myCommand = new SqlCommand("CR_FlatFileData", myConnection);
            myCommand.CommandType = CommandType.StoredProcedure;

            SqlParameter parameterEDREntryDate = new SqlParameter("@EDREntryDate", SqlDbType.VarChar);
            parameterEDREntryDate.Value = EDREntryDate;
            myCommand.Parameters.Add(parameterEDREntryDate);


            myConnection.Open();
            SqlDataReader dr = myCommand.ExecuteReader(CommandBehavior.CloseConnection);
            return dr;
        }


        public DataTable GetTransactionSentRejected_FlatFileDataByEDRID(Guid EDRID)
        {
            // Must enter your connection string
            SqlConnection myConnection = new SqlConnection(FLoraSoft.CR.DAL.AppVariables.ConStrVVDD);
            // Must write your procedure name 
            string spName = "CR_FlatFileData";
            SqlDataAdapter myAdapter = new SqlDataAdapter(spName, myConnection);
            myAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;
            myAdapter.SelectCommand.CommandTimeout = 600;

            SqlParameter parameterEDRID = new SqlParameter("@EDRID", SqlDbType.UniqueIdentifier);
            parameterEDRID.Value = EDRID;
            myAdapter.SelectCommand.Parameters.Add(parameterEDRID);

            DataTable myDT = new DataTable();
            myConnection.Open();
            myAdapter.Fill(myDT);
            myConnection.Close();
            return myDT;
        }

        public DataTable GetTransactionRejectedDataTable_ForFlatFile(string EDREntryDate)
        {
            // Must enter your connection string
            SqlConnection myConnection = new SqlConnection(FLoraSoft.CR.DAL.AppVariables.ConStrVVDD);
            // Must write your procedure name 
            string spName = "CR_FlatFileData";
            SqlDataAdapter myAdapter = new SqlDataAdapter(spName, myConnection);
            myAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;
            myAdapter.SelectCommand.CommandTimeout = 600;

            SqlParameter parameterEDREntryDate = new SqlParameter("@EDREntryDate", SqlDbType.VarChar);
            parameterEDREntryDate.Value = EDREntryDate;
            myAdapter.SelectCommand.Parameters.Add(parameterEDREntryDate);

            DataTable myDT = new DataTable();
            myConnection.Open();
            myAdapter.Fill(myDT);
            myConnection.Close();
            return myDT;
        }
        public void ClearFlatFileTable()
        {
            // Must enter your connection string
            SqlConnection myConnection = new SqlConnection(FLoraSoft.CR.DAL.AppVariables.ConStrVVDD);
            // Must write your procedure name 
            string spName = "CR_ClearFlatFileTable";
            SqlDataAdapter myAdapter = new SqlDataAdapter(spName, myConnection);
            myAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;
            myAdapter.SelectCommand.CommandTimeout = 600;

            myConnection.Open();
            myAdapter.SelectCommand.ExecuteNonQuery();
            myConnection.Close();
            myConnection.Dispose();
        }
    }
}