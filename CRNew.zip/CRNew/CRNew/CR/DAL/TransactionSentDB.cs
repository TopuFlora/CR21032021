﻿using System;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using IATPLibrary.Utility;
using Florasoft.CR.Utility;

namespace FLoraSoft.CR.DAL
{
    public class TransactionSentDB
    {
        public Guid InsertBatchSent(int BatchStatus, string BatchType, string CustomerACC)
        {// Must enter your connection string
            SqlConnection myConnection = new SqlConnection(FLoraSoft.CR.DAL.AppVariables.ConStrVVDD);
            // Must write your procedure name 
            SqlCommand myCommand = new SqlCommand("IATP_InsertBatchSent", myConnection);
            myCommand.CommandType = CommandType.StoredProcedure;

            SqlParameter parameterTransactionID = new SqlParameter("@TransactionID", SqlDbType.UniqueIdentifier);
            parameterTransactionID.Direction = ParameterDirection.Output;
            myCommand.Parameters.Add(parameterTransactionID);

            SqlParameter parameterBatchStatus = new SqlParameter("@BatchStatus", SqlDbType.Int);
            parameterBatchStatus.Value = BatchStatus;
            myCommand.Parameters.Add(parameterBatchStatus);

            SqlParameter parameterBatchType = new SqlParameter("@BatchType", SqlDbType.VarChar, 10);
            parameterBatchType.Value = BatchType;
            myCommand.Parameters.Add(parameterBatchType);

            SqlParameter parameterCustomerACC = new SqlParameter("@CustomerACC", SqlDbType.VarChar, 24);
            parameterCustomerACC.Value = CustomerACC;
            myCommand.Parameters.Add(parameterCustomerACC);

            myConnection.Open();
            myCommand.ExecuteNonQuery();
            myCommand.Dispose();
            myConnection.Close();
            myConnection.Dispose();

            return (Guid)parameterTransactionID.Value;
        }


        public Guid InsertTransactionSent(
                                    Guid TransactionID,
                                    string AccountNo,
                                    string AccountName,
                                    double Amount,
                                    string DocNo,
                                    string Nar1,
                                    string Nar2,
                                    string Nar3,
                                    string AccNameHUB,
                                    string GHOClassification,
                                    string AccountRestrisction,
                                    string SpecialIns1,
                                    string SpecialIns2,
                                    int CreationID

)
        {// Must enter your connection string
            SqlConnection myConnection = new SqlConnection(FLoraSoft.CR.DAL.AppVariables.ConStrVVDD);
            // Must write your procedure name 
            SqlCommand myCommand = new SqlCommand("IATP_InsertTransactionSent", myConnection);
            myCommand.CommandType = CommandType.StoredProcedure;

            SqlParameter parameterEDRID = new SqlParameter("@EDRID", SqlDbType.UniqueIdentifier);
            parameterEDRID.Direction = ParameterDirection.Output;
            myCommand.Parameters.Add(parameterEDRID);

            SqlParameter parameterTransactionID = new SqlParameter("@TransactionID", SqlDbType.UniqueIdentifier);
            parameterTransactionID.Value = TransactionID;
            myCommand.Parameters.Add(parameterTransactionID);

            SqlParameter parameterAccountNo = new SqlParameter("@AccountNo", SqlDbType.VarChar);
            parameterAccountNo.Value = AccountNo;
            myCommand.Parameters.Add(parameterAccountNo);

            SqlParameter parameterAccountName = new SqlParameter("@AccountName", SqlDbType.VarChar);
            parameterAccountName.Value = AccountName;
            myCommand.Parameters.Add(parameterAccountName);

            SqlParameter parameterAmount = new SqlParameter("@Amount", SqlDbType.Money);
            parameterAmount.Value = Amount;
            myCommand.Parameters.Add(parameterAmount);

            SqlParameter parameterDocNo = new SqlParameter("@DocNo", SqlDbType.VarChar);
            parameterDocNo.Value = DocNo;
            myCommand.Parameters.Add(parameterDocNo);

            SqlParameter parameterNar1 = new SqlParameter("@Nar1", SqlDbType.NVarChar, 200);
            parameterNar1.Value = Nar1;
            myCommand.Parameters.Add(parameterNar1);

            SqlParameter parameterNar2 = new SqlParameter("@Nar2", SqlDbType.NVarChar, 200);
            parameterNar2.Value = Nar2;
            myCommand.Parameters.Add(parameterNar2);

            SqlParameter parameterNar3 = new SqlParameter("@Nar3", SqlDbType.NVarChar, 200);
            parameterNar3.Value = Nar3;
            myCommand.Parameters.Add(parameterNar3);

            SqlParameter parameterAccNameHUB = new SqlParameter("@AccNameHUB", SqlDbType.VarChar);
            parameterAccNameHUB.Value = AccNameHUB;
            myCommand.Parameters.Add(parameterAccNameHUB);

            SqlParameter parameterGHOClassification = new SqlParameter("@GHOClassification", SqlDbType.NVarChar, 200);
            parameterGHOClassification.Value = GHOClassification;
            myCommand.Parameters.Add(parameterGHOClassification);

            SqlParameter parameterAccountRestrisction = new SqlParameter("@AccountRestrisction", SqlDbType.NVarChar, 200);
            parameterAccountRestrisction.Value = AccountRestrisction;
            myCommand.Parameters.Add(parameterAccountRestrisction);

            SqlParameter parameterSpecialIns1 = new SqlParameter("@SpecialIns1", SqlDbType.VarChar);
            parameterSpecialIns1.Value = SpecialIns1;
            myCommand.Parameters.Add(parameterSpecialIns1);

            SqlParameter parameterSpecialIns2 = new SqlParameter("@SpecialIns2", SqlDbType.VarChar);
            parameterSpecialIns2.Value = SpecialIns2;
            myCommand.Parameters.Add(parameterSpecialIns2);

            SqlParameter parameterCreationID = new SqlParameter("@CreationID", SqlDbType.Int);
            parameterCreationID.Value = CreationID;
            myCommand.Parameters.Add(parameterCreationID);

            myConnection.Open();
            myCommand.ExecuteNonQuery();
            myCommand.Dispose();
            myConnection.Close();
            myConnection.Dispose();

            return (Guid)parameterEDRID.Value;
        }

        public DataTable GetUploadedSentEDRByTransactionID(Guid TransactionID,
                                                            int pageNumber,
                                                            int pageSize
                                                          )
        {
            SqlConnection myConnection = new SqlConnection(FLoraSoft.CR.DAL.AppVariables.ConStrVVDD);
            // Must write your procedure name 
            SqlDataAdapter myAdapter = new SqlDataAdapter("IATP_GetSentEDR_ForMakerByTransactionID", myConnection);
            myAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;
            myAdapter.SelectCommand.CommandTimeout = 600;

            SqlParameter parameterTransactionID = new SqlParameter("@TransactionID", SqlDbType.UniqueIdentifier);
            parameterTransactionID.Value = TransactionID;
            myAdapter.SelectCommand.Parameters.Add(parameterTransactionID);

            SqlParameter parameterpageNumber = new SqlParameter("@pageNumber", SqlDbType.Int);
            parameterpageNumber.Value = pageNumber;
            myAdapter.SelectCommand.Parameters.Add(parameterpageNumber);

            SqlParameter parameterpageSize = new SqlParameter("@pageSize", SqlDbType.Int);
            parameterpageSize.Value = IATPPageSize.MakerUploadedPageSize;
            myAdapter.SelectCommand.Parameters.Add(parameterpageSize);

            DataTable dt = new DataTable();

            myConnection.Open();
            myAdapter.Fill(dt);
            myConnection.Close();
            myAdapter.Dispose();
            myConnection.Dispose();
            return dt;
        }


        public void UpdateSentEDR_TransectionByEDRID(Guid EDRID,
                                    string AccountNo,
                                    string AccountName,
                                    double Amount,
                                    string DocNo,
                                    string Nar1,
                                    string Nar2,
                                    string Nar3,
                                    string AccNameHUB,
                                    string GHOClassification,
                                    string AccountRestrisction,
                                    string SpecialIns1,
                                    string SpecialIns2,
                                    int CreationID)
        {// Must enter your connection string
            SqlConnection myConnection = new SqlConnection(FLoraSoft.CR.DAL.AppVariables.ConStrVVDD);
            // Must write your procedure name 
            SqlDataAdapter myAdapter = new SqlDataAdapter("IATP_UpdateSentEDR_Transaction", myConnection);
            myAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;
            myAdapter.SelectCommand.CommandTimeout = 600;

            SqlParameter parameterEDRID = new SqlParameter("@EDRID", SqlDbType.UniqueIdentifier);
            parameterEDRID.Value = EDRID;
            myAdapter.SelectCommand.Parameters.Add(parameterEDRID);

            SqlParameter parameterAccountNo = new SqlParameter("@AccountNo", SqlDbType.VarChar, 17);
            parameterAccountNo.Value = AccountNo;
            myAdapter.SelectCommand.Parameters.Add(parameterAccountNo);

            SqlParameter parameterAccountName = new SqlParameter("@AccountName", SqlDbType.VarChar, 500);
            parameterAccountName.Value = AccountName;
            myAdapter.SelectCommand.Parameters.Add(parameterAccountName);

            SqlParameter parameterAmount = new SqlParameter("@Amount", SqlDbType.Money);
            parameterAmount.Value = Amount;
            myAdapter.SelectCommand.Parameters.Add(parameterAmount);

            SqlParameter parameterDocNo = new SqlParameter("@DocNo", SqlDbType.VarChar, 50);
            parameterDocNo.Value = DocNo;
            myAdapter.SelectCommand.Parameters.Add(parameterDocNo);

            SqlParameter parameterNar1 = new SqlParameter("@Nar1", SqlDbType.NVarChar, 200);
            parameterNar1.Value = Nar1;
            myAdapter.SelectCommand.Parameters.Add(parameterNar1);

            SqlParameter parameterNar2 = new SqlParameter("@Nar2", SqlDbType.NVarChar, 200);
            parameterNar2.Value = Nar2;
            myAdapter.SelectCommand.Parameters.Add(parameterNar2);

            SqlParameter parameterNar3 = new SqlParameter("@Nar3", SqlDbType.NVarChar, 200);
            parameterNar3.Value = Nar3;
            myAdapter.SelectCommand.Parameters.Add(parameterNar3);

            SqlParameter parameterAccNameHUB = new SqlParameter("@AccNameHUB", SqlDbType.VarChar);
            parameterAccNameHUB.Value = AccNameHUB;
            myAdapter.SelectCommand.Parameters.Add(parameterAccNameHUB);

            SqlParameter parameterGHOClassification = new SqlParameter("@GHOClassification", SqlDbType.NVarChar, 200);
            parameterGHOClassification.Value = GHOClassification;
            myAdapter.SelectCommand.Parameters.Add(parameterGHOClassification);

            SqlParameter parameterAccountRestrisction = new SqlParameter("@AccountRestrisction", SqlDbType.NVarChar, 200);
            parameterAccountRestrisction.Value = AccountRestrisction;
            myAdapter.SelectCommand.Parameters.Add(parameterAccountRestrisction);

            SqlParameter parameterSpecialIns1 = new SqlParameter("@SpecialIns1", SqlDbType.NVarChar, 200);
            parameterSpecialIns1.Value = SpecialIns1;
            myAdapter.SelectCommand.Parameters.Add(parameterSpecialIns1);

            SqlParameter parameterSpecialIns2 = new SqlParameter("@SpecialIns2", SqlDbType.VarChar);
            parameterSpecialIns2.Value = SpecialIns2;
            myAdapter.SelectCommand.Parameters.Add(parameterSpecialIns2);

            SqlParameter parameterCreationID = new SqlParameter("@CreationID", SqlDbType.Int);
            parameterCreationID.Value = CreationID;
            myAdapter.SelectCommand.Parameters.Add(parameterCreationID);


            myConnection.Open();
            myAdapter.SelectCommand.ExecuteNonQuery();
            myConnection.Close();
            myConnection.Dispose();
        }

        public void DeleteSentEDR_ByEDRID(Guid EDRID, int Deletedby, string RejectReason)
        {
            SqlConnection myConnection = new SqlConnection(FLoraSoft.CR.DAL.AppVariables.ConStrVVDD);
            SqlCommand myCommand = new SqlCommand("IATP_DeleteSentEDR_ByEDRID", myConnection);
            myCommand.CommandType = CommandType.StoredProcedure;

            SqlParameter parameterEDRID = new SqlParameter("@EDRID", SqlDbType.UniqueIdentifier);
            parameterEDRID.Value = EDRID;
            myCommand.Parameters.Add(parameterEDRID);

            SqlParameter parameterDeletedby = new SqlParameter("@Deletedby", SqlDbType.Int);
            parameterDeletedby.Value = Deletedby;
            myCommand.Parameters.Add(parameterDeletedby);

            SqlParameter parameterRejectReason = new SqlParameter("@RejectReason", SqlDbType.VarChar);
            parameterRejectReason.Value = RejectReason;
            myCommand.Parameters.Add(parameterRejectReason);

            myConnection.Open();
            myCommand.ExecuteNonQuery();
            myConnection.Close();
            myConnection.Dispose();
            myCommand.Dispose();
        }

        public void DeleteSentEDR_ByTransactionID(Guid TransactionID)
        {
            SqlConnection myConnection = new SqlConnection(FLoraSoft.CR.DAL.AppVariables.ConStrVVDD);
            SqlCommand myCommand = new SqlCommand("IATP_DeleteSentEDR_ByTransactionID", myConnection);
            myCommand.CommandType = CommandType.StoredProcedure;

            SqlParameter parameterTransactionID = new SqlParameter("@TransactionID", SqlDbType.UniqueIdentifier);
            parameterTransactionID.Value = TransactionID;
            myCommand.Parameters.Add(parameterTransactionID);


            myConnection.Open();
            myCommand.ExecuteNonQuery();
            myConnection.Close();
            myConnection.Dispose();
            myCommand.Dispose();
        }

        public void CancelBatch_ByTransactionID(Guid TransactionID)
        {
            SqlConnection myConnection = new SqlConnection(FLoraSoft.CR.DAL.AppVariables.ConStrVVDD);
            SqlCommand myCommand = new SqlCommand("IATP_CancelSentEDR_ByTransactionID", myConnection);
            myCommand.CommandType = CommandType.StoredProcedure;

            SqlParameter parameterTransactionID = new SqlParameter("@TransactionID", SqlDbType.UniqueIdentifier);
            parameterTransactionID.Value = TransactionID;
            myCommand.Parameters.Add(parameterTransactionID);


            myConnection.Open();
            myCommand.ExecuteNonQuery();
            myConnection.Close();
            myConnection.Dispose();
            myCommand.Dispose();
        }

        public void MoveSentEDRToChecker(Guid TransactionID)
        {
            SqlConnection myConnection = new SqlConnection(FLoraSoft.CR.DAL.AppVariables.ConStrVVDD);
            SqlCommand myCommand = new SqlCommand("IATP_MoveSentEDRToChecker", myConnection);
            myCommand.CommandType = CommandType.StoredProcedure;

            SqlParameter parameterTransactionID = new SqlParameter("@TransactionID", SqlDbType.UniqueIdentifier);
            parameterTransactionID.Value = TransactionID;
            myCommand.Parameters.Add(parameterTransactionID);


            myConnection.Open();
            myCommand.ExecuteNonQuery();
            myConnection.Close();
            myConnection.Dispose();
            myCommand.Dispose();
        }

        public string GetTotalTransactions_ByTransactionID(Guid TransactionID)
        {// Must enter your connection string
            SqlConnection myConnection = new SqlConnection(FLoraSoft.CR.DAL.AppVariables.ConStrVVDD);
            // Must write your procedure name 
            SqlCommand myCommand = new SqlCommand("IATP_GetTotalTransactions_ByTransactionID", myConnection);
            myCommand.CommandType = CommandType.StoredProcedure;

            SqlParameter parameterTransactionID = new SqlParameter("@TransactionID", SqlDbType.UniqueIdentifier);
            parameterTransactionID.Value = TransactionID;
            myCommand.Parameters.Add(parameterTransactionID);

            SqlParameter parameterTotalTransaction = new SqlParameter("@TotalTransaction", SqlDbType.Int);
            parameterTotalTransaction.Direction = ParameterDirection.Output;
            myCommand.Parameters.Add(parameterTotalTransaction);

            myConnection.Open();
            myCommand.ExecuteNonQuery();
            string totalTransaction = parameterTotalTransaction.Value.ToString();
            myConnection.Close();
            myConnection.Dispose();
            myCommand.Dispose();
            return totalTransaction;
        }


        public DataTable GetTransactionsInfo_ByTransactionID(Guid TransactionID)
        {
            SqlConnection myConnection = new SqlConnection(FLoraSoft.CR.DAL.AppVariables.ConStrVVDD);
            // Must write your procedure name 
            SqlDataAdapter myAdapter = new SqlDataAdapter("IATP_GetTransactionsInfo_ByTransactionID", myConnection);
            myAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;
            myAdapter.SelectCommand.CommandTimeout = 600;

            SqlParameter parameterTransactionID = new SqlParameter("@TransactionID", SqlDbType.UniqueIdentifier);
            parameterTransactionID.Value = TransactionID;
            myAdapter.SelectCommand.Parameters.Add(parameterTransactionID);

            DataTable dt = new DataTable();

            myConnection.Open();
            myAdapter.Fill(dt);
            myConnection.Close();
            myAdapter.Dispose();
            myConnection.Dispose();
            return dt;
        }

        public DataTable GetTransactionsInfoForChecker_ByTransactionID(Guid TransactionID)
        {
            SqlConnection myConnection = new SqlConnection(FLoraSoft.CR.DAL.AppVariables.ConStrVVDD);
            // Must write your procedure name 
            SqlDataAdapter myAdapter = new SqlDataAdapter("IATP_GetTransactionsInfo_ForChecker_ByTransactionID", myConnection);
            myAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;
            myAdapter.SelectCommand.CommandTimeout = 600;

            SqlParameter parameterTransactionID = new SqlParameter("@TransactionID", SqlDbType.UniqueIdentifier);
            parameterTransactionID.Value = TransactionID;
            myAdapter.SelectCommand.Parameters.Add(parameterTransactionID);

            DataTable dt = new DataTable();

            myConnection.Open();
            myAdapter.Fill(dt);
            myConnection.Close();
            myAdapter.Dispose();
            myConnection.Dispose();
            return dt;
        }

        public DataTable IATP_GetRemainingBatches_ForMaker()
        {
            SqlConnection myConnection = new SqlConnection(FLoraSoft.CR.DAL.AppVariables.ConStrVVDD);
            SqlDataAdapter myAdapter = new SqlDataAdapter("IATP_GetRemainingBatches_ForMaker", myConnection);
            myAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;
            myAdapter.SelectCommand.CommandTimeout = 600;

            DataTable dt = new DataTable();

            myConnection.Open();
            myAdapter.Fill(dt);
            myConnection.Close();
            myAdapter.Dispose();
            myConnection.Dispose();
            return dt;
        }
    }
}