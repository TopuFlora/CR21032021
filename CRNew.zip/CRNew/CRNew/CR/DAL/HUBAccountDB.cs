﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using IATP.Utility;

namespace FLoraSoft.CR.DAL
{
    public class HUBAccountDB
    {
        public DataTable GetDistinctAccNoByTransactionID(Guid TransactionID)
        {// Must enter your connection string
            SqlConnection myConnection = new SqlConnection(IATPConnectionString.GetIATPConnectionString());
            // Must write your procedure name 
            SqlDataAdapter myAdapter = new SqlDataAdapter("IATP_GetDistinctAccountNoByTransactionID", myConnection);
            myAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;
            myAdapter.SelectCommand.CommandTimeout = 3600;

            SqlParameter parameterTransactionID = new SqlParameter("@TransactionID", SqlDbType.UniqueIdentifier);
            parameterTransactionID.Value = TransactionID;
            myAdapter.SelectCommand.Parameters.Add(parameterTransactionID);

            DataTable myDT = new DataTable();
            myConnection.Open();
            myAdapter.Fill(myDT);
            myConnection.Close();
            return myDT;
        }


        public void InsertHUBMapper(string AccNameHUB,
                                string GHOClassification,
                                string AccType,
                                string AccountStatus,
                                string AccountRestrisction,
                                string SpecialIns,
                                string ACCOUNTHUB,
                                string Others)
        {// Must enter your connection string
            SqlConnection myConnection = new SqlConnection(IATPConnectionString.GetIATPConnectionString());
            // Must write your procedure name 
            SqlDataAdapter myAdapter = new SqlDataAdapter("IATP_InsertHUBMapper", myConnection);
            myAdapter.SelectCommand.CommandType = CommandType.StoredProcedure;
            myAdapter.SelectCommand.CommandTimeout = 600;

            SqlParameter parameterAccNameHUB = new SqlParameter("@AccNameHUB", SqlDbType.NVarChar, 100);
            parameterAccNameHUB.Value = AccNameHUB;
            myAdapter.SelectCommand.Parameters.Add(parameterAccNameHUB);

            SqlParameter parameterGHOClassification = new SqlParameter("@GHOClassification", SqlDbType.NVarChar, 100);
            parameterGHOClassification.Value = GHOClassification;
            myAdapter.SelectCommand.Parameters.Add(parameterGHOClassification);

            SqlParameter parameterAccType = new SqlParameter("@AccType", SqlDbType.NVarChar, 100);
            parameterAccType.Value = AccType;
            myAdapter.SelectCommand.Parameters.Add(parameterAccType);

            SqlParameter parameterAccountStatus = new SqlParameter("@AccountStatus", SqlDbType.NVarChar, 100);
            parameterAccountStatus.Value = AccountStatus;
            myAdapter.SelectCommand.Parameters.Add(parameterAccountStatus);

            SqlParameter parameterAccountRestrisction = new SqlParameter("@AccountRestrisction", SqlDbType.NVarChar, 100);
            parameterAccountRestrisction.Value = AccountRestrisction;
            myAdapter.SelectCommand.Parameters.Add(parameterAccountRestrisction);

            SqlParameter parameterSpecialIns = new SqlParameter("@SpecialIns", SqlDbType.VarChar, 2000);
            parameterSpecialIns.Value = SpecialIns;
            myAdapter.SelectCommand.Parameters.Add(parameterSpecialIns);

            SqlParameter parameterACCOUNTHUB = new SqlParameter("@ACCOUNTHUB", SqlDbType.VarChar);
            parameterACCOUNTHUB.Value = ACCOUNTHUB;
            myAdapter.SelectCommand.Parameters.Add(parameterACCOUNTHUB);

            SqlParameter parameterOthers = new SqlParameter("@Others", SqlDbType.VarChar);
            parameterOthers.Value = Others;
            myAdapter.SelectCommand.Parameters.Add(parameterOthers);

            myConnection.Open();
            myAdapter.SelectCommand.ExecuteNonQuery();
            myConnection.Close();
            myConnection.Dispose();
        }
    }
}