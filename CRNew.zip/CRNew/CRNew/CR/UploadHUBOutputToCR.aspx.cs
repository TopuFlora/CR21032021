﻿using System;
using System.IO;
using System.Configuration;
using System.Data;
using IATP.Utility;
using ICSharpCode.SharpZipLib.Zip;
using ICSharpCode.SharpZipLib.Core;
using FLoraSoft.CR.DAL;
using FloraSoft.CR.DAL;
using Florasoft.CR.Utility;
using System.Text;

namespace FloraSoft.CR
{
    public partial class UploadHUBOutputToCR : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnUploadHUBOutput_Click(object sender, EventArgs e)
        {
            string fileName = string.Empty;
            string fileExtension = string.Empty;
            string fulfilePath = string.Empty;
            string savePath = string.Empty;
            string fileInFolder = Guid.NewGuid().ToString();
            string saveFolderPath = ConfigurationManager.AppSettings["EFTExcelFiles"] + fileInFolder;
            string PKZipPassword = ConfigurationManager.AppSettings["PKZipPassword"];
            try
            {
                fulfilePath = HUBoutputFile.PostedFile.FileName;

                fileExtension = Path.GetExtension(fulfilePath);

                fileName = Path.GetFileName(fulfilePath);

                if (!fileExtension.Equals(".zip"))
                {
                    fileExtension = ".zip";
                    fileName = fileName + ".zip";
                }
                savePath = saveFolderPath + "\\" + fileInFolder + fileExtension;
                Directory.CreateDirectory(saveFolderPath);

                HUBoutputFile.SaveAs(savePath);
                ExtractZipFile(savePath, PKZipPassword, saveFolderPath);
                //InsertUploadedData(saveFolderPath + "\\" + fileName.Substring(0, (fileName.Length - fileExtension.Length)));

                if (Directory.Exists(saveFolderPath))
                {
                    Directory.Delete(saveFolderPath, true);
                    lblErrMsg.Text = "Upload completed";
                    lblErrMsg.ForeColor = System.Drawing.Color.Blue;
                }
                //}
                //else
                //{
                //    lblErrMsg.Text = "The file extension is not .zip";
                //    lblErrMsg.ForeColor = System.Drawing.Color.Red;
                //}
            }
            catch (Exception ex)
            {
                lblErrMsg.Text = ex.Message;
                lblErrMsg.ForeColor = System.Drawing.Color.Red;
                if (Directory.Exists(saveFolderPath))
                {
                    Directory.Delete(saveFolderPath, true);
                }
            }
        }

        private void ExtractZipFile(string archiveFilenameIn, string password, string outFolder)
        {
            ZipFile zf = null;
            try
            {
                FileStream fs = File.OpenRead(archiveFilenameIn);
                zf = new ZipFile(fs);
                if (!String.IsNullOrEmpty(password))
                {
                    zf.Password = password;     // AES encrypted entries are handled automatically
                }
                foreach (ZipEntry zipEntry in zf)
                {
                    if (!zipEntry.IsFile)
                    {
                        continue;           // Ignore directories
                    }
                    String entryFileName = zipEntry.Name;
                    // to remove the folder from the entry:- entryFileName = Path.GetFileName(entryFileName);
                    // Optionally match entrynames against a selection list here to skip as desired.
                    // The unpacked length is available in the zipEntry.Size property.

                    byte[] buffer = new byte[4096];     // 4K is optimum
                    Stream zipStream = zf.GetInputStream(zipEntry);

                    // Manipulate the output filename here as desired.
                    String fullZipToPath = Path.Combine(outFolder, entryFileName);
                    string directoryName = Path.GetDirectoryName(fullZipToPath);
                    if (directoryName.Length > 0)
                        Directory.CreateDirectory(directoryName);

                    // Unzip file in buffered chunks. This is just as fast as unpacking to a buffer the full size
                    // of the file, but does not waste memory.
                    // The "using" will close the stream even if an exception occurs.
                    using (FileStream streamWriter = File.Create(fullZipToPath))
                    {
                        StreamUtils.Copy(zipStream, streamWriter, buffer);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (zf != null)
                {
                    zf.IsStreamOwner = true; // Makes close also shut the underlying stream
                    zf.Close(); // Ensure we release resources
                }
            }
        }

        //private void InsertUploadedData(string textFilePath)
        //{
        //    //EFTN.component.ExcelDB excelDB = new EFTN.component.ExcelDB();
        //    try
        //    {
        //        string delim = ConfigurationManager.AppSettings["TextDelim"];
        //        //DataTable data = DelimitedTextReader.ReadFile(textFilePath, delim);
        //        //HUBOutputDB outputDB = new HUBOutputDB();

        //        string colName_TraceNumber = string.Empty;
        //        string colName_AccountNumber = string.Empty;
        //        string colName_Amount = string.Empty;
        //        string colName_SPINARRATIVE = string.Empty;
        //        string colName_TRNStatus = string.Empty;
        //        string colName_RejectReason = string.Empty;

        //        foreach (DataColumn column in data.Columns)
        //        {
        //            string ColumnName = column.ColumnName;

        //            if (ColumnName.ToUpper().Trim().Equals("TRACE NUMBER"))
        //            {
        //                colName_TraceNumber = ColumnName;
        //            }
        //            else if (ColumnName.ToUpper().Trim().Equals("ACCOUNT NUMBER"))
        //            {
        //                colName_AccountNumber = ColumnName;
        //            }
        //            else if (ColumnName.ToUpper().Trim().Equals("AMOUNT"))
        //            {
        //                colName_Amount = ColumnName;
        //            }
        //            else if (ColumnName.ToUpper().Trim().Equals("SPI NARRATIVE"))
        //            {
        //                colName_SPINARRATIVE = ColumnName;
        //            }
        //            else if (ColumnName.ToUpper().Trim().Equals("TRN STATUS"))
        //            {
        //                colName_TRNStatus = ColumnName;
        //            }
        //            else if (ColumnName.ToUpper().Trim().Equals("REJECT REASON"))
        //            {
        //                colName_RejectReason = ColumnName;
        //            }
        //        }

        //        foreach (DataRow row in data.Rows)
        //        {
        //            //string colName_TraceNumber = ("Trace Number").PadRight(15, ' ');
        //            //string colName_AccountNumber = ("Account number").PadRight(18, ' ');
        //            //string colName_Amount = ("Amount").PadRight(17, ' ');
        //            //string colName_SPINARRATIVE = ("SPI NARRATIVE").PadRight(24, ' ');
        //            //string colName_TRNStatus = ("TRN Status").PadRight(11, ' ');
        //            //string colName_RejectReason = ("Reject Reason").PadRight(185, ' ');


        //            string TraceNumber = row[colName_TraceNumber].ToString();
        //            string AccountNumber = row[colName_AccountNumber].ToString();
        //            AccountNumber = AccountNumber.Substring(6, AccountNumber.Length - 6);
        //            string strAmount = row[colName_Amount].ToString();

        //            decimal Amount = 0;
        //            if (strAmount.Length < 15)
        //            {
        //                Amount = (ParseData.StringToDecimal(strAmount)) / 100;
        //            }
        //            string SPINARRATIVE = row[colName_SPINARRATIVE].ToString();
        //            string TRNStatus = row[colName_TRNStatus].ToString();
        //            string RejectReason = row[colName_RejectReason].ToString();

        //            outputDB.UpdateTransactionSent_FlatFileACK_FromHUB(TraceNumber, AccountNumber, Amount, SPINARRATIVE
        //                                                                , TRNStatus, RejectReason);
        //        }

        //        lblErrMsg.Text = "Upload completed";
        //        lblErrMsg.ForeColor = System.Drawing.Color.Blue;
        //    }
        //    catch (Exception ex)
        //    {
        //        lblErrMsg.Text = ex.Message;
        //        lblErrMsg.ForeColor = System.Drawing.Color.Red;
        //    }
        //}
    }
}