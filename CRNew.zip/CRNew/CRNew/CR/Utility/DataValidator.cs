﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text.RegularExpressions;

namespace Florasoft.CR.Utility
{
    public class DataValidator
    {
        public string GetOnlyNumeric(string inputString)
        {
            string resultString = null;
            try
            {
                Regex regexObj = new Regex(@"[^\d]");
                resultString = regexObj.Replace(inputString, "");
            }
            catch (ArgumentException ex)
            {
                // Syntax error in the regular expression
            }
            return resultString;
        }
    }
}