﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Configuration;

namespace IATP.Utility
{
    public static class IATPConnectionString
    {
        //ConfigurationManager.AppSettings["ConnectionStringIATP"]
        public static string GetIATPConnectionString()
        {
            return ConfigurationManager.AppSettings["ConnectionStringIATP"];
        }

        public static string GetACHConnectionString()
        {
            return ConfigurationManager.AppSettings["ConnectionStringACH"];
        }
    }
}