﻿using System;
using System.Collections.Generic;
using System.Web;

namespace Florasoft.CR.Utility
{
    public static class BatchStatus
    {
        public const int Maker = 1;
        public const int Rejected = 2;
        public const int Checker = 3;
        public const int SentToHUB = 4;
    }
}