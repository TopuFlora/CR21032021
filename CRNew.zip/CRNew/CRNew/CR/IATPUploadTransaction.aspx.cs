﻿using System;
using System.IO;
using System.Configuration;
using System.Data;
using System.Text;
using FloraSoft.CR.DAL;
using System.Web.UI.WebControls;
using IATPLibrary.Utility;
using FLoraSoft.CR.BLL;
using System.Collections.Generic;
using FLoraSoft.CR.DAL;
using Florasoft.CR.Utility;

namespace IATP
{
    public partial class IATPUploadTransaction : System.Web.UI.Page
    {

        private static string IATP_ExcelFile = string.Empty;
        private static DataTable dtExcel = new DataTable();
        //private static Guid TransactionID;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                HidePageControl();
            }
        }

        protected void btnUploadExcel_Click(object sender, EventArgs e)
        {
            IATP_ExcelFile = string.Empty;

            if (fulExcelFile.HasFile)
            {
                
                string extension = Path.GetExtension(fulExcelFile.PostedFile.FileName);
                string savePath = ConfigurationManager.AppSettings["EFTExcelFiles"] + Guid.NewGuid().ToString() + extension;
                //string fileName = string.Empty;

                fulExcelFile.SaveAs(savePath);

                IATP_ExcelFile = savePath;
                int rowNumber = -1;
                try
                {
                    if (extension.ToLower().Equals(".xls") || extension.ToLower().Equals(".xlsx"))
                    {
                        FloraSoft.CR.DAL.ExcelDB excelDB = new FloraSoft.CR.DAL.ExcelDB();
                        dtExcel = excelDB.GetDataTableFromDynamicSheetName(savePath, 0);
                        //read file from here.............
                        //......
                        StringBuilder errorString = new StringBuilder();
                        //int totalError = 0;
                        string[] columnName = new string[dtExcel.Columns.Count];

                        foreach (DataColumn dc in dtExcel.Columns)
                        {
                            columnName[++rowNumber] = dc.ColumnName;
                        }

                        if (rowNumber > -1)
                        {
                            ddListaccountno.DataSource = columnName;
                            ddListaccountno.DataBind();

                            ddListaccountname.DataSource = columnName;
                            ddListaccountname.DataBind();

                            ddListamount.DataSource = columnName;
                            ddListamount.DataBind();

                            ddListdocno.DataSource = columnName;
                            ddListdocno.DataBind();
                            ddListdocno.Items.Insert(0, "N/A");

                            ddListnarration1.DataSource = columnName;
                            ddListnarration1.DataBind();
                            //ddListnarration1.Items.Insert(0, "N/A");

                            ddListnarration2.DataSource = columnName;
                            ddListnarration2.DataBind();
                            ddListnarration2.Items.Insert(0, "N/A");

                            ddListnarration3.DataSource = columnName;
                            ddListnarration3.DataBind();
                            ddListnarration3.Items.Insert(0, "N/A");
                        }
                        lblErrMsg.Text = string.Empty;
                    }
                    else
                    {
                        lblErrMsg.Text = "Please select excel file";
                    }
                }
                catch (Exception ex)
                {
                    lblErrMsg.Text = ex.Message;
                }
            }
        }

        protected void linkBtnInsertData_Click(object sender, EventArgs e)
        {
            if (Session["UploadedTransactionID"] != null)
            {
                Session["UploadedTransactionID"] = null;
            }

            if (dtExcel.Rows.Count > 0)
            {
                FLoraSoft.CR.DAL.TransactionSentDB tranSentDB = new FLoraSoft.CR.DAL.TransactionSentDB();
                try
                {
                    string BatchType = rdoBtnListBatchType.SelectedValue;
                    string CustomerAcc = txtCustomerAcc.Text.Trim();

                    Guid TransactionID = tranSentDB.InsertBatchSent(1, BatchType, CustomerAcc);
                    Session["UploadedTransactionID"] = TransactionID.ToString();

                    int CreationID = ParseData.StringToInt(Request.Cookies["UserID"].Value);

                    DataValidator dataValidator = new DataValidator();

                    foreach (DataRow row in dtExcel.Rows)
                    {
                        string AccountNo = row[ddListaccountno.SelectedValue].ToString();
                        string AccountName = row[ddListaccountname.SelectedValue].ToString();
                        double Amount = ParseData.StringToDouble(row[ddListamount.SelectedValue].ToString());

                        string DocNo = string.Empty;

                        if (!ddListdocno.SelectedValue.Equals("N/A"))
                        {
                            DocNo = row[ddListdocno.SelectedValue].ToString().Trim();//DocNumber
                        }
                        //string DocNo = row[ddListdocno.SelectedValue].ToString();
                        string Nar1 = string.Empty;
                        string Nar2 = string.Empty;
                        string Nar3 = string.Empty;

                        if (!ddListnarration1.SelectedValue.Equals("N/A"))
                        {
                            Nar1 = row[ddListnarration1.SelectedValue].ToString().Trim();//DocNumber
                        }

                        if (!ddListnarration2.SelectedValue.Equals("N/A"))
                        {
                            Nar2 = row[ddListnarration2.SelectedValue].ToString().Trim();//DocNumber
                        }

                        if (!ddListnarration3.SelectedValue.Equals("N/A"))
                        {
                            Nar3 = row[ddListnarration3.SelectedValue].ToString().Trim();//DocNumber
                        }

                        string AccNameHUB = string.Empty;
                        string GHOClassification = string.Empty;
                        string AccountRestrisction = string.Empty;
                        string SpecialIns1 = string.Empty;
                        string SpecialIns2 = string.Empty;

                        AccountNo = dataValidator.GetOnlyNumeric(AccountNo);
                        if (DocNo.Trim().Length > OutwardTransactionFieldLength.DocNo)
                        {
                            DocNo = DocNo.Substring(0, 6);
                        }
                        //string AccNameHUB = row[ddListAccNameHUB.SelectedValue].ToString();
                        //string GHOClassification = row[ddListGHOClassification.SelectedValue].ToString();
                        //string AccountRestrisction = row[ddListAccountRestrisction.SelectedValue].ToString();
                        //string SpecialIns1 = row[ddListSpecialIns1.SelectedValue].ToString();
                        //string SpecialIns2 = row[ddListSpecialIns2.SelectedValue].ToString();

                        if (AccountNo.Trim().Equals(string.Empty))
                        {
                            continue;
                        }
                        Guid EDRID = tranSentDB.InsertTransactionSent(TransactionID, AccountNo, AccountName, Amount, DocNo
                                                            , Nar1, Nar2, Nar3, AccNameHUB, GHOClassification
                                                            , AccountRestrisction, SpecialIns1, SpecialIns2, CreationID);
                    }
                }
                catch
                {
                }
                txtPageNumber.Text = "1";
                lblPageNo.Text = "1";
                BindTotalPage();
                ShowPageControl();
            }
            System.IO.File.Delete(IATP_ExcelFile);

            //int TotalPage = dtExcel.Rows.Count / IATPPageSize.MakerUploadedPageSize;
            //if ((dtExcel.Rows.Count % IATPPageSize.MakerUploadedPageSize) != 0)
            //{
            //    TotalPage += 1;
            //}
            //lblTotalPage.Text = TotalPage.ToString();
            dtExcel.Clear();
        }

        private void BindUploadedData(int pageNumber)
        {
            FLoraSoft.CR.DAL.TransactionSentDB tranSentDB = new FLoraSoft.CR.DAL.TransactionSentDB();
            if (pageNumber < 1)
            {
                return;
            }
            if (System.Web.HttpContext.Current.Session["UploadedTransactionID"] == null)
            {
                return;
            }
            string strTransactionID = System.Web.HttpContext.Current.Session["UploadedTransactionID"].ToString();

            Guid TransactionID = new Guid(strTransactionID);

            DataTable dtUploadedData = tranSentDB.GetUploadedSentEDRByTransactionID(TransactionID, pageNumber, IATPPageSize.MakerUploadedPageSize);

            //TransactionColumnFromMQService txnColumnFromMQService = new TransactionColumnFromMQService();

            //dtUploadedData = txnColumnFromMQService.BindColumnFromMQService(dtUploadedData, UserID);

            gridViewTransaction.DataSource = dtUploadedData;
            gridViewTransaction.DataBind();

            lblPageNo.Text = pageNumber.ToString();
            txtPageNumber.Text = pageNumber.ToString();

        }

        private void HidePageControl()
        {
            divPageControl.Visible = false;
        }

        private void ShowPageControl()
        {
            divPageControl.Visible = true;
        }

        protected void gridViewTransaction_RowEditing(object sender, GridViewEditEventArgs e)
        {
            int pageNumber = ParseData.StringToInt(lblPageNo.Text);
            gridViewTransaction.EditIndex = e.NewEditIndex;
            BindUploadedData(pageNumber);
        }

        protected void gridViewTransaction_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

            string strEDRID = gridViewTransaction.DataKeys[e.RowIndex].Value.ToString();
            Guid EDRID = Guid.Parse(strEDRID);

            TextBox txtAccountNo = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtAccountNo");
            TextBox txtAccountName = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtAccountName");
            TextBox txtDocNo = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtDocNo");
            TextBox txtNar1 = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtNar1");
            TextBox txtNar2 = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtNar2");
            TextBox txtNar3 = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtNar3");
            TextBox txtAmount = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtAmount");

            TextBox txtAccNameHUB = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtAccNameHUB");
            TextBox txtGHOClassification = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtGHOClassification");
            TextBox txtAccountStatus = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtAccountStatus");
            TextBox txtAccountRestrisction = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtAccountRestrisction");
            TextBox txtSpecialIns1 = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtSpecialIns1");
            TextBox txtSpecialIns2 = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtSpecialIns2");

            FLoraSoft.CR.DAL.TransactionSentDB tranSentDB = new FLoraSoft.CR.DAL.TransactionSentDB();
            int CreationID = ParseData.StringToInt(Request.Cookies["UserID"].Value);

            tranSentDB.UpdateSentEDR_TransectionByEDRID(EDRID, txtAccountNo.Text.Trim(),
                                                                txtAccountName.Text.Trim(),
                                                                ParseData.StringToDouble(txtAmount.Text.Trim()),
                                                                txtDocNo.Text.Trim(), txtNar1.Text.Trim(),
                                                                txtNar2.Text.Trim(), txtNar3.Text.Trim(),
                                                                txtAccNameHUB.Text.Trim(), txtGHOClassification.Text.Trim(),
                                                                txtAccountRestrisction.Text.Trim(),
                                                                txtSpecialIns1.Text.Trim(), txtSpecialIns2.Text.Trim(),
                                                                CreationID);

            int pageNumber = ParseData.StringToInt(lblPageNo.Text);
            gridViewTransaction.EditIndex = -1;

            BindUploadedData(pageNumber);
        }


        //protected void gridViewTransaction_RowUpdating(object sender, GridViewUpdateEventArgs e)
        //{

        //    string strEDRID = gridViewTransaction.DataKeys[e.RowIndex].Value.ToString();
        //    Guid EDRID = Guid.Parse(strEDRID);

        //    TextBox txtAccountNo = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("AccountNo");
        //    TextBox txtAccountName = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("AccountName");
        //    TextBox txtAmount = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("Amount");
        //    TextBox txtDocNo = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("DocNo");
        //    TextBox txtNar1 = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("Nar1");
        //    TextBox txtNar2 = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("Nar2");
        //    TextBox txtNar3 = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("Nar3");
        //    TextBox txtAccNameHUB = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("AccNameHUB");
        //    TextBox txtGHOClassification = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("GHOClassification");
        //    TextBox txtAccountStatus = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("AccountStatusHUB");
        //    TextBox txtAccountRestrisction = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("AccountRestriction");
        //    TextBox txtSpecialIns1 = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("SpecialIns");
        //    TextBox txtSpecialIns2 = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("AccType");

        //    TransactionSentDB tranSentDB = new TransactionSentDB();
        //    int CreationID = ParseData.StringToInt(Request.Cookies["UserID"].Value);

        //    tranSentDB.UpdateSentEDR_TransectionByEDRID(EDRID, txtAccountNo.Text.Trim(),
        //                                                        txtAccountName.Text.Trim(),
        //                                                        ParseData.StringToDouble(txtAmount.Text.Trim()),
        //                                                        txtDocNo.Text.Trim(), txtNar1.Text.Trim(),
        //                                                        txtNar2.Text.Trim(), txtNar3.Text.Trim(),
        //                                                        txtAccNameHUB.Text.Trim(), txtGHOClassification.Text.Trim(),
        //                                                        txtAccountRestrisction.Text.Trim(),
        //                                                        txtSpecialIns1.Text.Trim(), txtSpecialIns2.Text.Trim(),
        //                                                        CreationID);

        //    int pageNumber = ParseData.StringToInt(lblPageNo.Text);
        //    gridViewTransaction.EditIndex = -1;

        //    BindUploadedData(pageNumber);
        //}

        protected void gridViewTransaction_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            int pageNumber = ParseData.StringToInt(lblPageNo.Text);
            gridViewTransaction.EditIndex = -1;
            BindUploadedData(pageNumber);
        }

        protected void gridViewTransaction_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int DeletedBy = ParseData.StringToInt(Request.Cookies["UserID"].Value);
            string strEDRID = gridViewTransaction.DataKeys[e.RowIndex].Value.ToString();
            Guid EDRID = Guid.Parse(strEDRID);
            FLoraSoft.CR.DAL.TransactionSentDB tranSentDB = new FLoraSoft.CR.DAL.TransactionSentDB();
            string RejectReason = txtRejectReason.Text.Trim();
            if (RejectReason.Equals(string.Empty))
            {
                lblMsgRejResn.Text = "Enter Reject Reason";
                lblMsgRejResn.ForeColor = System.Drawing.Color.Red;
                return;
            }
            else
            {
                lblMsgRejResn.Text = "";
            }

            tranSentDB.DeleteSentEDR_ByEDRID(EDRID, DeletedBy, RejectReason);
            BindTotalPage();
        }

        protected void linkBtnCancel_Click(object sender, EventArgs e)
        {
            //System.IO.File.Delete(IATP_ExcelFile);
            if (System.Web.HttpContext.Current.Session["UploadedTransactionID"] == null)
            {
                return;
            }
            string strTransactionID = System.Web.HttpContext.Current.Session["UploadedTransactionID"].ToString();

            Guid TransactionID = new Guid(strTransactionID);

            FLoraSoft.CR.DAL.TransactionSentDB dbo = new FLoraSoft.CR.DAL.TransactionSentDB();
            dbo.CancelBatch_ByTransactionID(TransactionID);

            ClearDropDownList();
            ClearPageInfo();
            HidePageControl();
            BindUploadedData(1);
        }

        private void ClearDropDownList()
        {
            ddListaccountname.Items.Clear();
            ddListaccountno.Items.Clear();
            ddListamount.Items.Clear();
            ddListdocno.Items.Clear();
            ddListnarration1.Items.Clear();
            ddListnarration2.Items.Clear();
            ddListnarration3.Items.Clear();
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            int pageNumber = ParseData.StringToInt(lblPageNo.Text.Trim());
            int totalPage = ParseData.StringToInt(lblTotalPage.Text.Trim());
            if (pageNumber == totalPage)
            {
                BindUploadedData(pageNumber);
            }
            else
            {
                pageNumber += 1;
                BindUploadedData(pageNumber);
            }
        }

        protected void btnLast_Click(object sender, EventArgs e)
        {
            int totalPage = ParseData.StringToInt(lblTotalPage.Text.Trim());
            BindUploadedData(totalPage);
        }

        protected void btnPrev_Click(object sender, EventArgs e)
        {
            int pageNumber = ParseData.StringToInt(lblPageNo.Text.Trim());
            if (pageNumber > 1)
            {
                pageNumber -= 1;
            }
            else
            {
                return;
            }
            BindUploadedData(pageNumber);
        }

        protected void btnFirstData_Click(object sender, EventArgs e)
        {
            BindUploadedData(1);
        }

        protected void btnGoToPage_Click(object sender, EventArgs e)
        {
            int pageNumber = ParseData.StringToInt(txtPageNumber.Text.Trim());
            int totalPage = ParseData.StringToInt(lblTotalPage.Text.Trim());

            if (pageNumber > 0 && pageNumber <= totalPage)
            {
                BindUploadedData(pageNumber);
            }
            else
            {
                return;
            }
        }

        private void BindTotalPage()
        {
            if (System.Web.HttpContext.Current.Session["UploadedTransactionID"] == null)
            {
                return;
            }

            string strTransactionID = System.Web.HttpContext.Current.Session["UploadedTransactionID"].ToString();

            Guid TransactionID = new Guid(strTransactionID);
            //Guid TransactionID = HttpContext.Current.Session["UploadedTransactionID"].ToString();
            FLoraSoft.CR.DAL.TransactionSentDB tranSentDB = new TransactionSentDB();
            int TotalTransaction = ParseData.StringToInt(tranSentDB.GetTotalTransactions_ByTransactionID(TransactionID));
            int TotalPage = TotalTransaction / IATPPageSize.MakerUploadedPageSize;

            if ((TotalTransaction % IATPPageSize.MakerUploadedPageSize) != 0)
            {
                TotalPage += 1;
            }
            lblTotalPage.Text = TotalPage.ToString();

            int pageNumber = ParseData.StringToInt(txtPageNumber.Text.Trim());
            if (pageNumber > TotalPage)
            {
                pageNumber = TotalPage;
            }

            BindUploadedData(pageNumber);
            BindTransactionTotalInformation();
        }

        private void BindTransactionTotalInformation()
        {
            if (System.Web.HttpContext.Current.Session["UploadedTransactionID"] == null)
            {
                return;
            }
            string strTransactionID = System.Web.HttpContext.Current.Session["UploadedTransactionID"].ToString();

            Guid TransactionID = new Guid(strTransactionID);

            TransactionSentDB sentDB = new TransactionSentDB();
            DataTable dtTotalInfo = sentDB.GetTransactionsInfo_ByTransactionID(TransactionID);
            string Amount = dtTotalInfo.Rows[0]["TotalAmount"].ToString();
            string BatchIdentity = dtTotalInfo.Rows[0]["BatchIdentity"].ToString();

            string AmountInWords = NumberToWordConverter.GetAmountInWords(Amount);
            lblTotalTransactionMsg.Text = "Batch Number - " + BatchIdentity + " : Total Item - " + dtTotalInfo.Rows[0]["TotalItem"].ToString() + " : Total Amount - " + Amount + " (" + AmountInWords + ")";
        }

        private void ClearPageInfo()
        {
            lblTotalTransactionMsg.Text = string.Empty;
        }

        protected void linkBtnSave_Click(object sender, EventArgs e)
        {
            if (System.Web.HttpContext.Current.Session["UploadedTransactionID"] == null)
            {
                return;
            }
            string strTransactionID = System.Web.HttpContext.Current.Session["UploadedTransactionID"].ToString();

            Guid TransactionID = new Guid(strTransactionID);

            TransactionSentDB sentDB = new TransactionSentDB();
            sentDB.MoveSentEDRToChecker(TransactionID);
            Response.Redirect("IATPMakerHome.aspx");
        }

        protected void linkBtnSyncWithHubAccount_Click(object sender, EventArgs e)
        {
            if (System.Web.HttpContext.Current.Session["UploadedTransactionID"] == null)
            {
                return;
            }
            string strTransactionID = System.Web.HttpContext.Current.Session["UploadedTransactionID"].ToString();

            Guid TransactionID = new Guid(strTransactionID);

            string UserID = Request.Cookies["LoginID"].Value;
            HUBAccountManager hubManager = new HUBAccountManager();
            hubManager.SynchronizeHUBAccountByTransactionID(TransactionID, UserID);
            BindUploadedData(1);
        }

        protected void gridViewTransaction_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow &&
               (e.Row.RowState == DataControlRowState.Normal ||
                e.Row.RowState == DataControlRowState.Alternate))
            {
                CheckBox chkBxSelect = (CheckBox)e.Row.Cells[1].FindControl("chkBxSelect");
                CheckBox chkBxHeader = (CheckBox)this.gridViewTransaction.HeaderRow.FindControl("chkBxHeader");
                chkBxSelect.Attributes["onclick"] = string.Format
                                                       (
                                                          "javascript:ChildClick(this,'{0}');",
                                                          chkBxHeader.ClientID
                                                       );
            }

        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            int DeletedBy = ParseData.StringToInt(Request.Cookies["UserID"].Value);
            //string strEDRID = gridViewTransaction.DataKeys[e.RowIndex].Value.ToString();
            //Guid EDRID = Guid.Parse(strEDRID);
            TransactionSentDB tranSentDB = new TransactionSentDB();
            string RejectReason = txtRejectReason.Text.Trim();
            int itemCounter = 0;
            if (RejectReason.Equals(string.Empty))
            {
                lblMsgRejResn.Text = "Enter Reject Reason";
                lblMsgRejResn.ForeColor = System.Drawing.Color.Red;
                return;
            }
            else
            {
                lblMsgRejResn.Text = "";
            }

            foreach (GridViewRow item in gridViewTransaction.Rows)
            {
                CheckBox myCheckBox = (CheckBox)item.FindControl("chkBxSelect");

                if (myCheckBox.Checked)
                {
                    string strEDRID = gridViewTransaction.DataKeys[item.RowIndex].Value.ToString();
                    Guid EDRID = Guid.Parse(strEDRID);

                    tranSentDB.DeleteSentEDR_ByEDRID(EDRID, DeletedBy, RejectReason);
                    //transentDB.UpdateSentEDR_fromChecker(EDRID, BatchStatus.Rejected, ApporverID, RejectReason);
                    itemCounter++;
                }
            }
            if (itemCounter > 0)
            {
                lblMsgRejResn.Text = "Data Deleted Successfully..";
                lblMsgRejResn.ForeColor = System.Drawing.Color.Blue;
            }
            else
            {
                lblMsgRejResn.Text = "Select Item to delete";
                lblMsgRejResn.ForeColor = System.Drawing.Color.Red;
            }


            BindTotalPage();

        }
    }
}
//    public partial class IATPUploadTransaction : System.Web.UI.Page
//    {

//        private static string IATP_ExcelFile = string.Empty;
//        private static DataTable dtExcel = new DataTable();
//        //private static Guid TransactionID;

//        protected void Page_Load(object sender, EventArgs e)
//        {
//            if (!IsPostBack)
//            {
//                HidePageControl();
//            }
//        }

//        protected void btnUploadExcel_Click(object sender, EventArgs e)
//        {
//            IATP_ExcelFile = string.Empty;

//            if (fulExcelFile.HasFile)
//            {
//                string extension = Path.GetExtension(fulExcelFile.PostedFile.FileName);
//                string savePath = ConfigurationManager.AppSettings["EFTExcelFiles"] + Guid.NewGuid().ToString() + extension;
//                //string fileName = string.Empty;

//                fulExcelFile.SaveAs(savePath);

//                IATP_ExcelFile = savePath;
//                int rowNumber = -1;
//                try
//                {
//                    if (extension.ToLower().Equals(".xls") || extension.ToLower().Equals(".xlsx"))
//                    {
//                        FloraSoft.CR.DAL.ExcelDB excelDB = new FloraSoft.CR.DAL.ExcelDB();
//                        dtExcel = excelDB.GetDataTableFromDynamicSheetName(savePath, 0);
//                        //read file from here.............
//                        //......
//                        StringBuilder errorString = new StringBuilder();
//                        //int totalError = 0;
//                        string[] columnName = new string[dtExcel.Columns.Count];

//                        foreach (DataColumn dc in dtExcel.Columns)
//                        {
//                            columnName[++rowNumber] = dc.ColumnName;
//                        }

//                        if (rowNumber > -1)
//                        {
//                            ddListaccountno.DataSource = columnName;
//                            ddListaccountno.DataBind();

//                            ddListaccountname.DataSource = columnName;
//                            ddListaccountname.DataBind();

//                            ddListamount.DataSource = columnName;
//                            ddListamount.DataBind();

//                            ddListdocno.DataSource = columnName;
//                            ddListdocno.DataBind();
//                            ddListdocno.Items.Insert(0, "N/A");

//                            ddListnarration1.DataSource = columnName;
//                            ddListnarration1.DataBind();
//                            //ddListnarration1.Items.Insert(0, "N/A");

//                            ddListnarration2.DataSource = columnName;
//                            ddListnarration2.DataBind();
//                            ddListnarration2.Items.Insert(0, "N/A");

//                            ddListnarration3.DataSource = columnName;
//                            ddListnarration3.DataBind();
//                            ddListnarration3.Items.Insert(0, "N/A");
//                        }
//                        lblErrMsg.Text = string.Empty;
//                    }
//                    else
//                    {
//                        lblErrMsg.Text = "Please select excel file";
//                    }
//                }
//                catch(Exception ex)
//                {
//                    lblErrMsg.Text = ex.Message;
//                }
//            }
//        }

//        protected void linkBtnInsertData_Click(object sender, EventArgs e)
//        {
//            if (Session["UploadedTransactionID"] != null)
//            {
//                Session["UploadedTransactionID"] = null;
//            }

//            if (dtExcel.Rows.Count > 0)
//            {

//                FLoraSoft.CR.DAL.TransactionSentDB tranSentDB = new FLoraSoft.CR.DAL.TransactionSentDB();
//                try
//                {
//                    string BatchType = rdoBtnListBatchType.SelectedValue;
//                    string CustomerAcc = txtCustomerAcc.Text.Trim();

//                    Guid TransactionID = tranSentDB.InsertBatchSent(1, BatchType, CustomerAcc);
//                    Session["UploadedTransactionID"] = TransactionID.ToString();

//                    int CreationID = Florasoft.CR.Utility.ParseData.StringToInt(Request.Cookies["UserID"].Value);

//                    DataValidator dataValidator = new DataValidator();

//                    foreach (DataRow row in dtExcel.Rows)
//                    {
//                        string AccountNo = row[ddListaccountno.SelectedValue].ToString();
//                        string AccountName = row[ddListaccountname.SelectedValue].ToString();
//                        double Amount = Florasoft.CR.Utility.ParseData.StringToDouble(row[ddListamount.SelectedValue].ToString());

//                        string DocNo = string.Empty;

//                        if (!ddListdocno.SelectedValue.Equals("N/A"))
//                        {
//                            DocNo = row[ddListdocno.SelectedValue].ToString().Trim();//DocNumber
//                        }
//                        //string DocNo = row[ddListdocno.SelectedValue].ToString();
//                        string Nar1 = string.Empty;
//                        string Nar2 = string.Empty;
//                        string Nar3 = string.Empty;

//                        if (!ddListnarration1.SelectedValue.Equals("N/A"))
//                        {
//                            Nar1 = row[ddListnarration1.SelectedValue].ToString().Trim();//DocNumber
//                        }

//                        if (!ddListnarration2.SelectedValue.Equals("N/A"))
//                        {
//                            Nar2 = row[ddListnarration2.SelectedValue].ToString().Trim();//DocNumber
//                        }

//                        if (!ddListnarration3.SelectedValue.Equals("N/A"))
//                        {
//                            Nar3= row[ddListnarration3.SelectedValue].ToString().Trim();//DocNumber
//                        }
                        
//                        string AccNameHUB = string.Empty;
//                        string GHOClassification = string.Empty;
//                        string AccountRestrisction = string.Empty;
//                        string SpecialIns1 = string.Empty;
//                        string SpecialIns2 = string.Empty;

//                        AccountNo = dataValidator.GetOnlyNumeric(AccountNo);
//                        if (DocNo.Trim().Length > OutwardTransactionFieldLength.DocNo)
//                        {
//                            DocNo = DocNo.Substring(0, 6);
//                        }
//                        //string AccNameHUB = row[ddListAccNameHUB.SelectedValue].ToString();
//                        //string GHOClassification = row[ddListGHOClassification.SelectedValue].ToString();
//                        //string AccountRestrisction = row[ddListAccountRestrisction.SelectedValue].ToString();
//                        //string SpecialIns1 = row[ddListSpecialIns1.SelectedValue].ToString();
//                        //string SpecialIns2 = row[ddListSpecialIns2.SelectedValue].ToString();

//                        if (AccountNo.Trim().Equals(string.Empty))
//                        {
//                            continue;
//                        }
//                        Guid EDRID = tranSentDB.InsertTransactionSent(TransactionID, AccountNo, AccountName, Amount, DocNo
//                                                            , Nar1, Nar2, Nar3, AccNameHUB, GHOClassification
//                                                            , AccountRestrisction, SpecialIns1, SpecialIns2, CreationID);
//                    }
//                }
//                catch
//                {
//                }
//                txtPageNumber.Text = "1";
//                lblPageNo.Text = "1";
//                BindTotalPage();
//                ShowPageControl();
//            }
//            System.IO.File.Delete(IATP_ExcelFile);

//            //int TotalPage = dtExcel.Rows.Count / IATPPageSize.MakerUploadedPageSize;
//            //if ((dtExcel.Rows.Count % IATPPageSize.MakerUploadedPageSize) != 0)
//            //{
//            //    TotalPage += 1;
//            //}
//            //lblTotalPage.Text = TotalPage.ToString();
//            dtExcel.Clear();
//        }

//        private void BindUploadedData(int pageNumber)
//        {
//            FLoraSoft.CR.DAL.TransactionSentDB tranSentDB = new FLoraSoft.CR.DAL.TransactionSentDB();
//            if (pageNumber < 1)
//            {
//                return;
//            }
//            if (System.Web.HttpContext.Current.Session["UploadedTransactionID"] == null)
//            {
//                return;
//            }
//            string strTransactionID = System.Web.HttpContext.Current.Session["UploadedTransactionID"].ToString();

//            Guid TransactionID = new Guid(strTransactionID);

//            DataTable dtUploadedData = tranSentDB.GetUploadedSentEDRByTransactionID(TransactionID, pageNumber, IATPPageSize.MakerUploadedPageSize);

//            //TransactionColumnFromMQService txnColumnFromMQService = new TransactionColumnFromMQService();

//            //dtUploadedData = txnColumnFromMQService.BindColumnFromMQService(dtUploadedData, UserID);

//            gridViewTransaction.DataSource = dtUploadedData;
//            gridViewTransaction.DataBind();

//            lblPageNo.Text = pageNumber.ToString();
//            txtPageNumber.Text = pageNumber.ToString();

//        }
        
//        private void HidePageControl()
//        {
//            divPageControl.Visible = false;
//        }

//        private void ShowPageControl()
//        {
//            divPageControl.Visible = true;
//        }
//        //ParseData.StringToInt(lblPageNo.Text);
//        protected void gridViewTransaction_RowEditing(object sender, GridViewEditEventArgs e)
//        {
//            int pageNumber = Florasoft.CR.Utility.ParseData.ToInt(lblPageNo.Text);
//            gridViewTransaction.EditIndex = e.NewEditIndex;
//            BindUploadedData(pageNumber);
//        }

//        protected void gridViewTransaction_RowUpdating(object sender, GridViewUpdateEventArgs e)
//        {

//            string strEDRID = gridViewTransaction.DataKeys[e.RowIndex].Value.ToString();
//            Guid EDRID = Guid.Parse(strEDRID);

//            TextBox txtAccountNo = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtAccountNo");
//            TextBox txtAccountName = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtAccountName");
//            TextBox txtDocNo = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtDocNo");
//            TextBox txtNar1 = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtNar1");
//            TextBox txtNar2 = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtNar2");
//            TextBox txtNar3 = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtNar3");
//            TextBox txtAmount = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtAmount");

//            TextBox txtAccNameHUB = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtAccNameHUB");
//            TextBox txtGHOClassification = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtGHOClassification");
//            TextBox txtAccountStatus = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtAccountStatus");
//            TextBox txtAccountRestrisction = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtAccountRestrisction");
//            TextBox txtSpecialIns1 = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtSpecialIns1");
//            TextBox txtSpecialIns2 = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("txtSpecialIns2");

//            FLoraSoft.CR.DAL.TransactionSentDB tranSentDB = new FLoraSoft.CR.DAL.TransactionSentDB();
//            int CreationID = Florasoft.CR.Utility.ParseData.ToInt(Request.Cookies["UserID"].Value);

//            tranSentDB.UpdateSentEDR_TransectionByEDRID(EDRID, txtAccountNo.Text.Trim(),
//                                                                txtAccountName.Text.Trim(),
//                                                                Florasoft.CR.Utility.ParseData.ToDouble(txtAmount.Text.Trim()),
//                                                                txtDocNo.Text.Trim(), txtNar1.Text.Trim(),
//                                                                txtNar2.Text.Trim(), txtNar3.Text.Trim(),
//                                                                txtAccNameHUB.Text.Trim(), txtGHOClassification.Text.Trim(),
//                                                                txtAccountRestrisction.Text.Trim(),
//                                                                txtSpecialIns1.Text.Trim(), txtSpecialIns2.Text.Trim(),
//                                                                CreationID);

//            int pageNumber = FLoraSoft.CR.DAL.AppVariables.ConStrVVDDStringToInt(lblPageNo.Text);
//            gridViewTransaction.EditIndex = -1;

//            BindUploadedData(pageNumber);
//        }


//        //protected void gridViewTransaction_RowUpdating(object sender, GridViewUpdateEventArgs e)
//        //{

//        //    string strEDRID = gridViewTransaction.DataKeys[e.RowIndex].Value.ToString();
//        //    Guid EDRID = Guid.Parse(strEDRID);

//        //    TextBox txtAccountNo = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("AccountNo");
//        //    TextBox txtAccountName = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("AccountName");
//        //    TextBox txtAmount = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("Amount");
//        //    TextBox txtDocNo = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("DocNo");
//        //    TextBox txtNar1 = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("Nar1");
//        //    TextBox txtNar2 = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("Nar2");
//        //    TextBox txtNar3 = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("Nar3");
//        //    TextBox txtAccNameHUB = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("AccNameHUB");
//        //    TextBox txtGHOClassification = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("GHOClassification");
//        //    TextBox txtAccountStatus = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("AccountStatusHUB");
//        //    TextBox txtAccountRestrisction = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("AccountRestriction");
//        //    TextBox txtSpecialIns1 = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("SpecialIns");
//        //    TextBox txtSpecialIns2 = (TextBox)gridViewTransaction.Rows[e.RowIndex].FindControl("AccType");

//        //    TransactionSentDB tranSentDB = new TransactionSentDB();
//        //    int CreationID = FLoraSoft.CR.DAL.AppVariables.ConStrVVDDStringToInt(Request.Cookies["UserID"].Value);

//        //    tranSentDB.UpdateSentEDR_TransectionByEDRID(EDRID, txtAccountNo.Text.Trim(),
//        //                                                        txtAccountName.Text.Trim(),
//        //                                                        FLoraSoft.CR.DAL.AppVariables.ConStrVVDDStringToDouble(txtAmount.Text.Trim()),
//        //                                                        txtDocNo.Text.Trim(), txtNar1.Text.Trim(),
//        //                                                        txtNar2.Text.Trim(), txtNar3.Text.Trim(),
//        //                                                        txtAccNameHUB.Text.Trim(), txtGHOClassification.Text.Trim(),
//        //                                                        txtAccountRestrisction.Text.Trim(),
//        //                                                        txtSpecialIns1.Text.Trim(), txtSpecialIns2.Text.Trim(),
//        //                                                        CreationID);

//        //    int pageNumber = FLoraSoft.CR.DAL.AppVariables.ConStrVVDDStringToInt(lblPageNo.Text);
//        //    gridViewTransaction.EditIndex = -1;

//        //    BindUploadedData(pageNumber);
//        //}

//        protected void gridViewTransaction_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
//        {
//            int pageNumber = FLoraSoft.CR.DAL.AppVariables.ConStrVVDDStringToInt(lblPageNo.Text);
//            gridViewTransaction.EditIndex = -1;
//            BindUploadedData(pageNumber);
//        }

//        protected void gridViewTransaction_RowDeleting(object sender, GridViewDeleteEventArgs e)
//        {
//            int DeletedBy = FLoraSoft.CR.DAL.AppVariables.ConStrVVDDStringToInt(Request.Cookies["UserID"].Value);
//            string strEDRID = gridViewTransaction.DataKeys[e.RowIndex].Value.ToString();
//            Guid EDRID = Guid.Parse(strEDRID);
//            FLoraSoft.CR.DAL.TransactionSentDB tranSentDB = new FLoraSoft.CR.DAL.TransactionSentDB();
//            string RejectReason = txtRejectReason.Text.Trim();
//            if (RejectReason.Equals(string.Empty))
//            {
//                lblMsgRejResn.Text = "Enter Reject Reason";
//                lblMsgRejResn.ForeColor = System.Drawing.Color.Red;
//                return;
//            }
//            else
//            {
//                lblMsgRejResn.Text = "";
//            }

//            tranSentDB.DeleteSentEDR_ByEDRID(EDRID, DeletedBy, RejectReason);
//            BindTotalPage();
//        }

//        protected void linkBtnCancel_Click(object sender, EventArgs e)
//        {
//            //System.IO.File.Delete(IATP_ExcelFile);
//            if (System.Web.HttpContext.Current.Session["UploadedTransactionID"] == null)
//            {
//                return;
//            }
//            string strTransactionID = System.Web.HttpContext.Current.Session["UploadedTransactionID"].ToString();

//            Guid TransactionID = new Guid(strTransactionID);

//            FLoraSoft.CR.DAL.TransactionSentDB dbo = new FLoraSoft.CR.DAL.TransactionSentDB();
//            dbo.CancelBatch_ByTransactionID(TransactionID);

//            ClearDropDownList();
//            ClearPageInfo();
//            HidePageControl();
//            BindUploadedData(1);
//        }

//        private void ClearDropDownList()
//        {
//            ddListaccountname.Items.Clear();
//            ddListaccountno.Items.Clear();
//            ddListamount.Items.Clear();
//            ddListdocno.Items.Clear();
//            ddListnarration1.Items.Clear();
//            ddListnarration2.Items.Clear();
//            ddListnarration3.Items.Clear();
//        }

//        protected void btnNext_Click(object sender, EventArgs e)
//        {
//            int pageNumber = FLoraSoft.CR.DAL.AppVariables.ConStrVVDDStringToInt(lblPageNo.Text.Trim());
//            int totalPage = FLoraSoft.CR.DAL.AppVariables.ConStrVVDDStringToInt(lblTotalPage.Text.Trim());
//            if (pageNumber == totalPage)
//            {
//                BindUploadedData(pageNumber);
//            }
//            else
//            {
//                pageNumber += 1;
//                BindUploadedData(pageNumber);
//            }
//        }

//        protected void btnLast_Click(object sender, EventArgs e)
//        {
//            int totalPage = FLoraSoft.CR.DAL.AppVariables.ConStrVVDDStringToInt(lblTotalPage.Text.Trim());
//            BindUploadedData(totalPage);
//        }

//        protected void btnPrev_Click(object sender, EventArgs e)
//        {
//            int pageNumber = ParseData.StringToInt(lblPageNo.Text.Trim());
//            if (pageNumber > 1)
//            {
//                pageNumber -= 1;
//            }
//            else
//            {
//                return;
//            }
//            BindUploadedData(pageNumber);
//        }

//        protected void btnFirstData_Click(object sender, EventArgs e)
//        {
//            BindUploadedData(1);
//        }

//        protected void btnGoToPage_Click(object sender, EventArgs e)
//        {
//            int pageNumber = ParseData.StringToInt(txtPageNumber.Text.Trim());
//            int totalPage = ParseData.StringToInt(lblTotalPage.Text.Trim());

//            if (pageNumber > 0 && pageNumber <= totalPage)
//            {
//                BindUploadedData(pageNumber);
//            }
//            else
//            {
//                return;
//            }
//        }

//        private void BindTotalPage()
//        {
//            if (System.Web.HttpContext.Current.Session["UploadedTransactionID"] == null)
//            {
//                return;
//            }
            
//            string strTransactionID = System.Web.HttpContext.Current.Session["UploadedTransactionID"].ToString();

//            Guid TransactionID = new Guid(strTransactionID);
//            //Guid TransactionID = HttpContext.Current.Session["UploadedTransactionID"].ToString();
//            FLoraSoft.CR.DAL.TransactionSentDB tranSentDB = new FLoraSoft.CR.DAL.TransactionSentDB();
//            int TotalTransaction = ParseData.StringToInt(tranSentDB.GetTotalTransactions_ByTransactionID(TransactionID));
//            int TotalPage = TotalTransaction / IATPPageSize.MakerUploadedPageSize;

//            if ((TotalTransaction % IATPPageSize.MakerUploadedPageSize) != 0)
//            {
//                TotalPage += 1;
//            }
//            lblTotalPage.Text = TotalPage.ToString();

//            int pageNumber = ParseData.StringToInt(txtPageNumber.Text.Trim());
//            if (pageNumber > TotalPage)
//            {
//                pageNumber = TotalPage;
//            }

//            BindUploadedData(pageNumber);
//            BindTransactionTotalInformation();
//        }

//        private void BindTransactionTotalInformation()
//        {
//            if (System.Web.HttpContext.Current.Session["UploadedTransactionID"] == null)
//            {
//                return;
//            }
//            string strTransactionID = System.Web.HttpContext.Current.Session["UploadedTransactionID"].ToString();

//            Guid TransactionID = new Guid(strTransactionID);

//            FLoraSoft.CR.DAL.TransactionSentDB sentDB = new FLoraSoft.CR.DAL.TransactionSentDB();
//            DataTable dtTotalInfo = sentDB.GetTransactionsInfo_ByTransactionID(TransactionID);
//            string Amount = dtTotalInfo.Rows[0]["TotalAmount"].ToString();
//            string BatchIdentity = dtTotalInfo.Rows[0]["BatchIdentity"].ToString();

//            string AmountInWords = NumberToWordConverter.GetAmountInWords(Amount);
//            lblTotalTransactionMsg.Text = "Batch Number - " + BatchIdentity + " : Total Item - " + dtTotalInfo.Rows[0]["TotalItem"].ToString() + " : Total Amount - " + Amount + " (" + AmountInWords + ")";
//        }

//        private void ClearPageInfo()
//        {
//            lblTotalTransactionMsg.Text = string.Empty;
//        }

//        protected void linkBtnSave_Click(object sender, EventArgs e)
//        {
//            if (System.Web.HttpContext.Current.Session["UploadedTransactionID"] == null)
//            {
//                return;
//            }
//            string strTransactionID = System.Web.HttpContext.Current.Session["UploadedTransactionID"].ToString();

//            Guid TransactionID = new Guid(strTransactionID);

//            FLoraSoft.CR.DAL.TransactionSentDB sentDB = new FLoraSoft.CR.DAL.TransactionSentDB();
//            sentDB.MoveSentEDRToChecker(TransactionID);
//            Response.Redirect("IATPMakerHome.aspx");
//        }

//        protected void linkBtnSyncWithHubAccount_Click(object sender, EventArgs e)
//        {
//            if (System.Web.HttpContext.Current.Session["UploadedTransactionID"] == null)
//            {
//                return;
//            }
//            string strTransactionID = System.Web.HttpContext.Current.Session["UploadedTransactionID"].ToString();

//            Guid TransactionID = new Guid(strTransactionID);

//            string UserID = Request.Cookies["LoginID"].Value;
//            HUBAccountManager hubManager = new HUBAccountManager();
//            hubManager.SynchronizeHUBAccountByTransactionID(TransactionID, UserID);
//            BindUploadedData(1);
//        }

//        protected void gridViewTransaction_RowCreated(object sender, GridViewRowEventArgs e)
//        {
//            if (e.Row.RowType == DataControlRowType.DataRow &&
//               (e.Row.RowState == DataControlRowState.Normal ||
//                e.Row.RowState == DataControlRowState.Alternate))
//            {
//                CheckBox chkBxSelect = (CheckBox)e.Row.Cells[1].FindControl("chkBxSelect");
//                CheckBox chkBxHeader = (CheckBox)this.gridViewTransaction.HeaderRow.FindControl("chkBxHeader");
//                chkBxSelect.Attributes["onclick"] = string.Format
//                                                       (
//                                                          "javascript:ChildClick(this,'{0}');",
//                                                          chkBxHeader.ClientID
//                                                       );
//            }

//        }

//        protected void btnDelete_Click(object sender, EventArgs e)
//        {
//            int DeletedBy = ParseData.StringToInt(Request.Cookies["UserID"].Value);
//            //string strEDRID = gridViewTransaction.DataKeys[e.RowIndex].Value.ToString();
//            //Guid EDRID = Guid.Parse(strEDRID);
//            FLoraSoft.CR.DAL.TransactionSentDB tranSentDB = new FLoraSoft.CR.DAL.TransactionSentDB();
//            string RejectReason = txtRejectReason.Text.Trim();
//            int itemCounter = 0;
//            if (RejectReason.Equals(string.Empty))
//            {
//                lblMsgRejResn.Text = "Enter Reject Reason";
//                lblMsgRejResn.ForeColor = System.Drawing.Color.Red;
//                return;
//            }
//            else
//            {
//                lblMsgRejResn.Text = "";
//            }

//            foreach (GridViewRow item in gridViewTransaction.Rows)
//            {
//                CheckBox myCheckBox = (CheckBox)item.FindControl("chkBxSelect");

//                if (myCheckBox.Checked)
//                {
//                    string strEDRID = gridViewTransaction.DataKeys[item.RowIndex].Value.ToString();
//                    Guid EDRID = Guid.Parse(strEDRID);

//                    tranSentDB.DeleteSentEDR_ByEDRID(EDRID, DeletedBy, RejectReason);
//                    //transentDB.UpdateSentEDR_fromChecker(EDRID, BatchStatus.Rejected, ApporverID, RejectReason);
//                    itemCounter++;
//                }
//            }
//            if (itemCounter > 0)
//            {
//                lblMsgRejResn.Text = "Data Deleted Successfully..";
//                lblMsgRejResn.ForeColor = System.Drawing.Color.Blue;
//            }
//            else
//            {
//                lblMsgRejResn.Text = "Select Item to delete";
//                lblMsgRejResn.ForeColor = System.Drawing.Color.Red;
//            }


//            BindTotalPage();

//        }
//    }
//}